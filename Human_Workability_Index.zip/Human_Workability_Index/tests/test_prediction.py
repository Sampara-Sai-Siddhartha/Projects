import os
import sys

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import pandas as pd

from models.predict_attack import predict_attack

df = pd.read_csv(
    "synthetic_dataset/engineered_dataset.csv"
)

result = predict_attack(df)

print(result[["Prediction"]].value_counts())

print(result.head(20))