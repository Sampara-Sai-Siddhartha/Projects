import os
import sys

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import pandas as pd

from detection.rule_engine import RuleEngine

df = pd.read_csv("synthetic_dataset/engineered_dataset.csv")

engine = RuleEngine()

print("=" * 50)

for i in range(20):

    attacks = engine.evaluate(df.iloc[i])

    print(i, attacks)

print("=" * 50)