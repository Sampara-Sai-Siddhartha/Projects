"""
-------------------------------------------------------
FDI Detector Test

Tests:
1. Normal Data
2. Isolation Forest Anomaly
3. Historical Deviation
4. Weather Mismatch
5. Combined Evidence

-------------------------------------------------------
"""

import pandas as pd

from detection.fdi_detector import FDIDetector

# -------------------------------------------------------
# Sample History
# -------------------------------------------------------

history = pd.DataFrame({

    "Temperature(°C)": [32.0]*10,
    "Humidity(%)": [50]*10,
    "Pressure(hPa)": [1005]*10

})

weather = {

    "Temperature": 32,
    "Humidity": 50,
    "Pressure": 1005

}

detector = FDIDetector()

print("="*60)
print("FALSE DATA INJECTION DETECTOR TEST")
print("="*60)

# =======================================================
# TEST 1
# =======================================================

print("\nTEST 1 : Normal Data")

sensor = pd.Series({

    "Temperature(°C)":32,
    "Humidity(%)":50,
    "Pressure(hPa)":1005

})

print(detector.evaluate(
    sensor,
    history,
    weather,
    False
))

# =======================================================
# TEST 2
# =======================================================

print("\nTEST 2 : Isolation Forest Only")

print(detector.evaluate(
    sensor,
    history,
    weather,
    True
))

# =======================================================
# TEST 3
# =======================================================

print("\nTEST 3 : Historical Deviation")

sensor2 = pd.Series({

    "Temperature(°C)":45,
    "Humidity(%)":50,
    "Pressure(hPa)":1005

})

print(detector.evaluate(
    sensor2,
    history,
    weather,
    False
))

# =======================================================
# TEST 4
# =======================================================

print("\nTEST 4 : Weather Mismatch")

weather2 = {

    "Temperature":30,
    "Humidity":70,
    "Pressure":995

}

print(detector.evaluate(
    sensor,
    history,
    weather2,
    False
))

# =======================================================
# TEST 5
# =======================================================

print("\nTEST 5 : Combined Evidence")

print(detector.evaluate(
    sensor2,
    history,
    weather2,
    True
))

print("\n")
print("="*60)
print("TEST COMPLETED")
print("="*60)