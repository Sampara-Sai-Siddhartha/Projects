import os
import sys

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import pandas as pd

from attacks.attack_engine import AttackEngine
from attacks.scenario_generator import ScenarioGenerator

# Create dummy dataset
df = pd.DataFrame({

    "Temperature(°C)": [34]*100,

    "Humidity(%)": [65]*100,

    "Pressure(hPa)": [1006]*100,

    "Attack": [0]*100,

    "AttackName": ["Normal"]*100

})

# Generate attack events
generator = ScenarioGenerator(dataset_size=len(df))

events = generator.generate(n_events=5)

print("\nGenerated Events\n")

for event in events:
    print(event)

print("\nApplying attacks...\n")

engine = AttackEngine()

df = engine.apply_events(df, events)

print("\nModified Dataset (First 20 Rows)\n")

print(df.head(20))