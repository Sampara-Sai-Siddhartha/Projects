import os
import sys

# Add project root to Python path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import pandas as pd

from attacks.attack_profiles import FalseDataInjection
from attacks.attack_event import AttackEvent

# Create sample dataset
df = pd.DataFrame({
    "Temperature(°C)": [34] * 20,
    "Humidity(%)": [65] * 20,
    "Attack": [0] * 20,
    "AttackName": ["Normal"] * 20
})

# Create a test attack event
event = AttackEvent(
    event_id=1,
    attack_id=1,
    attack_name="False Data Injection",
    start_index=5,
    duration=5,
    intensity="High",
    affected_sensors=[
        "Temperature(°C)",
        "Humidity(%)"
    ]
)

attack = FalseDataInjection()

df = attack.apply(df, event)

print(df)