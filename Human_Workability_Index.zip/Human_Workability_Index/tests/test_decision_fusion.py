import os
import sys

PROJECT_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..")
)

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from detection.decision_fusion import DecisionFusion

fusion = DecisionFusion()

print("="*50)

print(
    fusion.fuse(
        [],
        "Normal"
    )
)

print(
    fusion.fuse(
        [],
        "Attack"
    )
)

print(
    fusion.fuse(
        ["Frozen Sensor"],
        "Normal"
    )
)

print(
    fusion.fuse(
        ["Missing Data"],
        "Attack"
    )
)

print("="*50)