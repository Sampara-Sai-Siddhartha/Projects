"""
-------------------------------------------------------
Test Temporal Detector

Tests:
1. Normal Sequence
2. Duplicate Polling
3. Timestamp Rollback
4. Duplicate Timestamp
5. Duplicate Packet

Author : Sai Siddhartha
-------------------------------------------------------
"""

import sys
import os
import pandas as pd

# ------------------------------------------------------
# Project Root
# ------------------------------------------------------

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

sys.path.insert(0, PROJECT_ROOT)

from detection.temporal_detector import TemporalDetector


# ------------------------------------------------------
# Sample Data
# ------------------------------------------------------

rows = [

    {
        "Date": "2026-07-14",
        "Time": "11:30:00",
        "Temperature(°C)": 32.0,
        "Humidity(%)": 60,
        "Pressure(hPa)": 1005,
        "AQI": 65,
        "Gas (kOhms)": 470,
        "Altitude(m)": 60,
        "DewPoint(°C)": 25,
        "HeatIndex(°C)": 36
    },

    {
        "Date": "2026-07-14",
        "Time": "11:31:00",
        "Temperature(°C)": 32.3,
        "Humidity(%)": 61,
        "Pressure(hPa)": 1005,
        "AQI": 65,
        "Gas (kOhms)": 470,
        "Altitude(m)": 60,
        "DewPoint(°C)": 25,
        "HeatIndex(°C)": 36
    },

    {
        "Date": "2026-07-14",
        "Time": "11:32:00",
        "Temperature(°C)": 32.5,
        "Humidity(%)": 61,
        "Pressure(hPa)": 1005,
        "AQI": 65,
        "Gas (kOhms)": 470,
        "Altitude(m)": 60,
        "DewPoint(°C)": 25,
        "HeatIndex(°C)": 36
    }

]

df = pd.DataFrame(rows)

detector = TemporalDetector()

print("=" * 60)
print("TEMPORAL DETECTOR TEST")
print("=" * 60)

# ------------------------------------------------------
# Test 1
# ------------------------------------------------------

print("\nTEST 1 : Normal Sequence")

for _, row in df.iterrows():

    print(detector.evaluate(row))

# ------------------------------------------------------
# Test 2
# ------------------------------------------------------

print("\nTEST 2 : Duplicate Polling")

row = df.iloc[2]

print(detector.evaluate(row))

# ------------------------------------------------------
# Test 3
# ------------------------------------------------------

print("\nTEST 3 : Timestamp Rollback")

rollback = df.iloc[1].copy()

rollback.name = 100

print(detector.evaluate(rollback))

# ------------------------------------------------------
# Test 4
# ------------------------------------------------------

print("\nTEST 4 : Duplicate Timestamp")

duplicate = df.iloc[2].copy()

duplicate.name = 101

print(detector.evaluate(duplicate))

# ------------------------------------------------------
# Test 5
# ------------------------------------------------------

print("\nTEST 5 : Duplicate Packet")

packet = df.iloc[0].copy()

packet["Date"] = "2026-07-14"

packet["Time"] = "11:40:00"

packet.name = 102

print(detector.evaluate(packet))

print("\n")
print("=" * 60)
print("TEST COMPLETED")
print("=" * 60)