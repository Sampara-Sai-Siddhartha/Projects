import pandas as pd

df = pd.read_csv("synthetic_dataset/engineered_dataset.csv")

frozen = df[df["AttackName"] == "Frozen Sensor"]

print(frozen[
[
    "Temperature(°C)",
    "Humidity(%)",
    "Pressure(hPa)",
    "TempRate",
    "HumidityRate",
    "PressureRate",
    "ConstantTempCount",
    "ConstantHumidityCount",
    "ConstantPressureCount"
]
].head(30))