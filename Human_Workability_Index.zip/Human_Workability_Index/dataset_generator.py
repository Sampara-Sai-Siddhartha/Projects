"""
-------------------------------------------------------
Dataset Generator
-------------------------------------------------------

Reads the real AeroSense dataset,
generates attack scenarios,
applies attacks,
and saves a synthetic dataset.

Author : Sai Siddhartha
Project : Secure Human Workability Index
-------------------------------------------------------
"""

import pandas as pd

from attacks.scenario_generator import ScenarioGenerator
from attacks.attack_engine import AttackEngine


# ==========================================================
# File Paths
# ==========================================================

INPUT_FILE = "data/aerosense_base.csv"
OUTPUT_FILE = "synthetic_dataset/synthetic_attack_dataset.csv"


# ==========================================================
# Main Function
# ==========================================================

def main():

    print("=" * 60)
    print("      SYNTHETIC CYBER DATASET GENERATOR")
    print("=" * 60)

    # ------------------------------------------------------
    # Load Dataset
    # ------------------------------------------------------

    print("\nLoading AeroSense Dataset...")

    df = pd.read_csv(INPUT_FILE)

    print(f"Rows Loaded : {len(df)}")

    # ------------------------------------------------------
    # Initialize Attack Columns
    # ------------------------------------------------------

    if "Attack" not in df.columns:
        df["Attack"] = 0

    if "AttackName" not in df.columns:
        df["AttackName"] = "Normal"

    # ------------------------------------------------------
    # Generate Attack Scenarios
    # ------------------------------------------------------

    print("\nGenerating Attack Scenarios...")

    generator = ScenarioGenerator(len(df))

    events = generator.generate(n_events=100)

    print(f"Attack Events Generated : {len(events)}")

    # ------------------------------------------------------
    # Apply Attacks
    # ------------------------------------------------------

    print("\nApplying Attack Profiles...")

    engine = AttackEngine()

    df = engine.apply_events(df, events)

    # ------------------------------------------------------
    # Save Dataset
    # ------------------------------------------------------

    print("\nSaving Synthetic Dataset...")

    df.to_csv(OUTPUT_FILE, index=False)

    print("\nDataset Successfully Created!")

    print(f"\nSaved To : {OUTPUT_FILE}")

    print("=" * 60)


# ==========================================================
# Driver Code
# ==========================================================

if __name__ == "__main__":
    main()