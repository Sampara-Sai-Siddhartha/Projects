"""
-------------------------------------------------------
Plots Module

Generates all plots for the evaluation.

Author : Sai Siddhartha
Project : Secure Human Workability Index
-------------------------------------------------------
"""

import os
import numpy as np
import matplotlib.pyplot as plt

from sklearn.metrics import (
    confusion_matrix,
    ConfusionMatrixDisplay,
    roc_curve,
    auc,
    precision_recall_curve
)

from config import RESULTS


# =====================================================
# Save Figure
# =====================================================

def save_plot(filename):

    plt.tight_layout()

    plt.savefig(

        os.path.join(
            RESULTS,
            filename
        ),

        dpi=300,

        bbox_inches="tight"

    )

    plt.close()


# =====================================================
# Confusion Matrix
# =====================================================

def plot_confusion_matrix(y_true, y_pred):

    print("Generating Confusion Matrix...")

    cm = confusion_matrix(

        y_true,

        y_pred

    )

    fig, ax = plt.subplots(figsize=(6,6))

    disp = ConfusionMatrixDisplay(

        confusion_matrix=cm,

        display_labels=["Normal","Attack"]

    )

    disp.plot(

        cmap="Blues",

        ax=ax,

        colorbar=False

    )

    plt.title("Confusion Matrix")

    save_plot("confusion_matrix.png")


# =====================================================
# ROC Curve
# =====================================================

def plot_roc_curve(y_true, y_pred):

    print("Generating ROC Curve...")

    fpr, tpr, _ = roc_curve(

        y_true,

        y_pred

    )

    roc_auc = auc(

        fpr,

        tpr

    )

    plt.figure(figsize=(7,6))

    plt.plot(

        fpr,

        tpr,

        linewidth=2,

        label=f"AUC = {roc_auc:.3f}"

    )

    plt.plot(

        [0,1],

        [0,1],

        linestyle="--"

    )

    plt.xlabel("False Positive Rate")

    plt.ylabel("True Positive Rate")

    plt.title("ROC Curve")

    plt.legend()

    plt.grid(True)

    save_plot("roc_curve.png")


# =====================================================
# Precision Recall Curve
# =====================================================

def plot_precision_recall_curve(y_true, y_pred):

    print("Generating Precision Recall Curve...")

    precision, recall, _ = precision_recall_curve(

        y_true,

        y_pred

    )

    plt.figure(figsize=(7,6))

    plt.plot(

        recall,

        precision,

        linewidth=2

    )

    plt.xlabel("Recall")

    plt.ylabel("Precision")

    plt.title("Precision Recall Curve")

    plt.grid(True)

    save_plot("precision_recall_curve.png")
    
# =====================================================
# Attack Distribution
# =====================================================

def plot_attack_distribution(df):

    print("Generating Attack Distribution...")

    attack_names = {

        0: "Normal",
        1: "FDI",
        4: "Sudden Spike",
        5: "Frozen Sensor"

    }

    counts = df["Attack"].value_counts().sort_index()

    labels = [
        attack_names.get(i, str(i))
        for i in counts.index
    ]

    plt.figure(figsize=(8,5))

    plt.bar(
        labels,
        counts.values
    )

    plt.title("Attack Distribution")

    plt.xlabel("Attack Type")

    plt.ylabel("Number of Samples")

    plt.grid(axis="y")

    save_plot("attack_distribution.png")


# =====================================================
# Prediction Distribution
# =====================================================

def plot_prediction_distribution(y_pred):

    print("Generating Prediction Distribution...")

    normal = sum(np.array(y_pred) == 0)

    attack = sum(np.array(y_pred) == 1)

    plt.figure(figsize=(6,6))

    plt.pie(

        [normal, attack],

        labels=["Normal", "Attack"],

        autopct="%1.1f%%",

        startangle=90

    )

    plt.title("Prediction Distribution")

    save_plot("prediction_distribution.png")


# =====================================================
# Temperature Trend
# =====================================================

def plot_temperature_trend(df):

    print("Generating Temperature Trend...")

    plt.figure(figsize=(10,4))

    plt.plot(

        df["Temperature(°C)"],

        linewidth=1

    )

    plt.title("Temperature Trend")

    plt.xlabel("Samples")

    plt.ylabel("Temperature (°C)")

    plt.grid(True)

    save_plot("temperature_trend.png")


# =====================================================
# Humidity Trend
# =====================================================

def plot_humidity_trend(df):

    print("Generating Humidity Trend...")

    plt.figure(figsize=(10,4))

    plt.plot(

        df["Humidity(%)"],

        linewidth=1

    )

    plt.title("Humidity Trend")

    plt.xlabel("Samples")

    plt.ylabel("Humidity (%)")

    plt.grid(True)

    save_plot("humidity_trend.png")


# =====================================================
# Pressure Trend
# =====================================================

def plot_pressure_trend(df):

    print("Generating Pressure Trend...")

    plt.figure(figsize=(10,4))

    plt.plot(

        df["Pressure(hPa)"],

        linewidth=1

    )

    plt.title("Pressure Trend")

    plt.xlabel("Samples")

    plt.ylabel("Pressure (hPa)")

    plt.grid(True)

    save_plot("pressure_trend.png")
    
# =====================================================
# AQI Trend
# =====================================================

def plot_aqi_trend(df):

    if "AQI" not in df.columns:
        return

    print("Generating AQI Trend...")

    plt.figure(figsize=(10,4))

    plt.plot(
        df["AQI"],
        linewidth=1.5
    )

    plt.title("AQI Trend")

    plt.xlabel("Samples")

    plt.ylabel("AQI")

    plt.grid(True)

    save_plot("aqi_trend.png")


# =====================================================
# Gas Trend
# =====================================================

def plot_gas_trend(df):

    if "Gas (kOhms)" not in df.columns:
        return

    print("Generating Gas Trend...")

    plt.figure(figsize=(10,4))

    plt.plot(
        df["Gas (kOhms)"],
        linewidth=1.5
    )

    plt.title("Gas Sensor Trend")

    plt.xlabel("Samples")

    plt.ylabel("Gas (kOhms)")

    plt.grid(True)

    save_plot("gas_trend.png")


# =====================================================
# Heat Index Trend
# =====================================================

def plot_heat_index(df):

    if "HeatIndex(°C)" not in df.columns:
        return

    print("Generating Heat Index Trend...")

    plt.figure(figsize=(10,4))

    plt.plot(
        df["HeatIndex(°C)"],
        linewidth=1.5
    )

    plt.title("Heat Index Trend")

    plt.xlabel("Samples")

    plt.ylabel("Heat Index (°C)")

    plt.grid(True)

    save_plot("heat_index_trend.png")


# =====================================================
# Human Workability Index Trend
# =====================================================

def plot_hwi_trend(df):

    if "HWI" not in df.columns:
        return

    print("Generating HWI Trend...")

    plt.figure(figsize=(10,4))

    plt.plot(
        df["HWI"],
        linewidth=2
    )

    plt.title("Human Workability Index Trend")

    plt.xlabel("Samples")

    plt.ylabel("HWI")

    plt.grid(True)

    save_plot("hwi_trend.png")


# =====================================================
# Combined Environmental Parameters
# =====================================================

def plot_environment(df):

    print("Generating Environmental Parameters Plot...")

    plt.figure(figsize=(12,6))

    if "Temperature(°C)" in df.columns:
        plt.plot(
            df["Temperature(°C)"],
            label="Temperature"
        )

    if "Humidity(%)" in df.columns:
        plt.plot(
            df["Humidity(%)"],
            label="Humidity"
        )

    if "Pressure(hPa)" in df.columns:
        plt.plot(
            df["Pressure(hPa)"],
            label="Pressure"
        )

    plt.title("Environmental Parameters")

    plt.xlabel("Samples")

    plt.legend()

    plt.grid(True)

    save_plot("environmental_parameters.png")


# =====================================================
# Generate All Plots
# =====================================================

def generate_all_plots(df, y_true, y_pred):

    print("\n====================================")
    print("Generating All Evaluation Plots")
    print("====================================\n")

    # Machine Learning Evaluation

    plot_confusion_matrix(
        y_true,
        y_pred
    )

    plot_roc_curve(
        y_true,
        y_pred
    )

    plot_precision_recall_curve(
        y_true,
        y_pred
    )

    # Dataset Statistics

    plot_attack_distribution(df)

    plot_prediction_distribution(y_pred)

    # Environmental Trends

    plot_temperature_trend(df)

    plot_humidity_trend(df)

    plot_pressure_trend(df)

    plot_aqi_trend(df)

    plot_gas_trend(df)

    plot_heat_index(df)

    plot_hwi_trend(df)

    plot_environment(df)

    print("\nAll plots generated successfully.")