"""
-------------------------------------------------------
Hybrid Model Evaluation

Compares:
1. Isolation Forest
2. Rule-Based Detection
3. Proposed Hybrid Decision Fusion

Author : Sai Siddhartha
-------------------------------------------------------
"""

import os
import sys
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix
)

# =====================================================
# Project Root
# =====================================================

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

sys.path.insert(0, PROJECT_ROOT)

# =====================================================
# Project Modules
# =====================================================

from detection.rule_engine import RuleEngine
from detection.decision_fusion import DecisionFusion
from detection.temporal_detector import TemporalDetector
from detection.fdi_detector import FDIDetector

from models.predict_attack import predict_attack


# =====================================================
# Paths
# =====================================================

DATASET_PATH = os.path.join(
    PROJECT_ROOT,
    "synthetic_dataset",
    "engineered_dataset.csv"
)

RESULTS_DIR = os.path.join(
    PROJECT_ROOT,
    "results"
)

os.makedirs(RESULTS_DIR, exist_ok=True)


# =====================================================
# Metric Calculation
# =====================================================

def calculate_metrics(y_true, y_pred):

    try:
        auc = roc_auc_score(y_true, y_pred)
    except ValueError:
        auc = 0.0

    return {
        "Accuracy": accuracy_score(y_true, y_pred),
        "Precision": precision_score(
            y_true, y_pred, zero_division=0
        ),
        "Recall": recall_score(
            y_true, y_pred, zero_division=0
        ),
        "F1 Score": f1_score(
            y_true, y_pred, zero_division=0
        ),
        "ROC AUC": auc
    }


# =====================================================
# Main Evaluation
# =====================================================

def main():

    print("=" * 70)
    print("HYBRID CYBERATTACK DETECTION EVALUATION")
    print("=" * 70)

    # -------------------------------------------------
    # Load Dataset
    # -------------------------------------------------

    print("\nLoading Dataset...")

    df = pd.read_csv(DATASET_PATH)

    print("Rows :", len(df))

    # Binary Ground Truth
    # 0 = Normal
    # 1 = Any Attack

    y_true = (
        df["Attack"]
        .apply(lambda x: 0 if x == 0 else 1)
        .tolist()
    )

    # -------------------------------------------------
    # 1. Isolation Forest
    # -------------------------------------------------

    print("\nRunning Isolation Forest...")

    ml_df = predict_attack(df.copy())

    ml_predictions_text = ml_df["Prediction"].tolist()

    ml_predictions = [
        1 if prediction == "Attack" else 0
        for prediction in ml_predictions_text
    ]

    print("Isolation Forest Completed")

    # -------------------------------------------------
    # 2. Rule Engine
    # -------------------------------------------------

    print("\nRunning Rule Engine...")

    rule_engine = RuleEngine()
    
    temporal_detector = TemporalDetector()
    fdi_detector = FDIDetector()

    fusion_engine = DecisionFusion()

    rule_predictions = []
    
    replay_predictions=[]

    fdi_predictions=[]

    hybrid_predictions=[]

    rule_attack_lists = []

    for _, row in df.iterrows():

        attacks = rule_engine.evaluate(row)

        rule_attack_lists.append(attacks)

        if len(attacks) > 0:
            rule_predictions.append(1)
        else:
            rule_predictions.append(0)

    print("Rule Engine Completed")

    # -------------------------------------------------
    # 3. Hybrid Decision Fusion
    # -------------------------------------------------

    print("\nRunning Hybrid Decision Fusion...")

    fusion_engine = DecisionFusion()

    hybrid_predictions = []

    hybrid_attack_types = []

    for rule_attacks, ml_prediction in zip(
        rule_attack_lists,
        ml_predictions_text
    ):

        result = fusion_engine.fuse(
            rule_attacks,
            ml_prediction
        )

        if result["AttackDetected"]:
            hybrid_predictions.append(1)
        else:
            hybrid_predictions.append(0)

        hybrid_attack_types.append(
            result["AttackType"]
        )

    print("Hybrid Decision Fusion Completed")

    # -------------------------------------------------
    # Calculate Metrics
    # -------------------------------------------------

    isolation_metrics = calculate_metrics(
        y_true,
        ml_predictions
    )

    rule_metrics = calculate_metrics(
        y_true,
        rule_predictions
    )

    hybrid_metrics = calculate_metrics(
        y_true,
        hybrid_predictions
    )

    # -------------------------------------------------
    # Results Table
    # -------------------------------------------------

    results = pd.DataFrame({

        "Model": [
            "Isolation Forest",
            "Rule-Based Detection",
            "Hybrid Decision Fusion"
        ],

        "Accuracy": [
            isolation_metrics["Accuracy"],
            rule_metrics["Accuracy"],
            hybrid_metrics["Accuracy"]
        ],

        "Precision": [
            isolation_metrics["Precision"],
            rule_metrics["Precision"],
            hybrid_metrics["Precision"]
        ],

        "Recall": [
            isolation_metrics["Recall"],
            rule_metrics["Recall"],
            hybrid_metrics["Recall"]
        ],

        "F1 Score": [
            isolation_metrics["F1 Score"],
            rule_metrics["F1 Score"],
            hybrid_metrics["F1 Score"]
        ],

        "ROC AUC": [
            isolation_metrics["ROC AUC"],
            rule_metrics["ROC AUC"],
            hybrid_metrics["ROC AUC"]
        ]
    })

    print("\n" + "=" * 70)
    print("MODEL COMPARISON")
    print("=" * 70)

    print(
        results.to_string(
            index=False,
            float_format=lambda x: f"{x:.4f}"
        )
    )

    # -------------------------------------------------
    # Confusion Matrices
    # -------------------------------------------------

    print("\nIsolation Forest Confusion Matrix:")
    print(confusion_matrix(
        y_true,
        ml_predictions
    ))

    print("\nRule Engine Confusion Matrix:")
    print(confusion_matrix(
        y_true,
        rule_predictions
    ))

    print("\nHybrid Model Confusion Matrix:")
    print(confusion_matrix(
        y_true,
        hybrid_predictions
    ))

    # -------------------------------------------------
    # Save Comparison CSV
    # -------------------------------------------------

    results.to_csv(
        os.path.join(
            RESULTS_DIR,
            "hybrid_model_comparison.csv"
        ),
        index=False
    )

    # -------------------------------------------------
    # Save Detailed Predictions
    # -------------------------------------------------

    prediction_results = df.copy()

    prediction_results["GroundTruthBinary"] = y_true

    prediction_results["IsolationForestPrediction"] = (
        ml_predictions
    )

    prediction_results["RuleEnginePrediction"] = (
        rule_predictions
    )

    prediction_results["HybridPrediction"] = (
        hybrid_predictions
    )

    prediction_results["HybridAttackType"] = (
        hybrid_attack_types
    )

    prediction_results.to_csv(
        os.path.join(
            RESULTS_DIR,
            "hybrid_predictions.csv"
        ),
        index=False
    )

    # -------------------------------------------------
    # Comparison Bar Chart
    # -------------------------------------------------

    metrics_to_plot = [
        "Accuracy",
        "Precision",
        "Recall",
        "F1 Score",
        "ROC AUC"
    ]

    plot_data = results.set_index(
        "Model"
    )[metrics_to_plot].T

    ax = plot_data.plot(
        kind="bar",
        figsize=(11, 6)
    )

    plt.title(
        "Comparison of Cyberattack Detection Methods"
    )

    plt.xlabel("Evaluation Metric")

    plt.ylabel("Score")

    plt.ylim(0, 1)

    plt.xticks(rotation=0)

    plt.legend(
        title="Detection Method"
    )

    plt.grid(
        axis="y",
        alpha=0.3
    )

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            RESULTS_DIR,
            "hybrid_model_comparison.png"
        ),
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()

    print("\nResults saved successfully:")
    print(
        "results/hybrid_model_comparison.csv"
    )
    print(
        "results/hybrid_predictions.csv"
    )
    print(
        "results/hybrid_model_comparison.png"
    )

    print("\n" + "=" * 70)
    print("HYBRID EVALUATION COMPLETED")
    print("=" * 70)


if __name__ == "__main__":
    main()