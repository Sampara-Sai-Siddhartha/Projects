import os
import sys
import pandas as pd

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

sys.path.insert(0, PROJECT_ROOT)

from detection.rule_engine import RuleEngine


DATASET = os.path.join(
    PROJECT_ROOT,
    "synthetic_dataset",
    "engineered_dataset.csv"
)


def main():

    df = pd.read_csv(DATASET)

    engine = RuleEngine()

    counts = {
        "Missing Data": 0,
        "Out Of Range": 0,
        "Sudden Spike": 0,
        "Frozen Sensor": 0
    }

    normal_trigger_counts = counts.copy()
    attack_trigger_counts = counts.copy()

    for _, row in df.iterrows():

        attacks = engine.evaluate(row)

        is_real_attack = row["Attack"] != 0

        for attack in attacks:

            counts[attack] += 1

            if is_real_attack:
                attack_trigger_counts[attack] += 1
            else:
                normal_trigger_counts[attack] += 1

    print("=" * 60)
    print("RULE ENGINE DIAGNOSTICS")
    print("=" * 60)

    print("\nTotal Rule Triggers:")
    for rule, count in counts.items():
        print(f"{rule:20s}: {count}")

    print("\nTriggers on NORMAL samples (False Alarms):")
    for rule, count in normal_trigger_counts.items():
        print(f"{rule:20s}: {count}")

    print("\nTriggers on ATTACK samples (Correct Detections):")
    for rule, count in attack_trigger_counts.items():
        print(f"{rule:20s}: {count}")


if __name__ == "__main__":
    main()