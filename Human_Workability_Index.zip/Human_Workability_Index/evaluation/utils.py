"""
-------------------------------------------------------
Utility Functions

Author : Sai Siddhartha
-------------------------------------------------------
"""

import os


def ensure_directory(path):

    """
    Creates directory if it does not exist.
    """

    if not os.path.exists(path):

        os.makedirs(path)


def print_header(title):

    print("\n" + "="*60)

    print(title)

    print("="*60)