"""
-------------------------------------------------------
Main Evaluation Script

Loads:
    Dataset
    Isolation Forest Model

Runs:
    Predictions
    Metrics
    Plots
    Reports

Author : Sai Siddhartha
-------------------------------------------------------
"""

import pandas as pd
import joblib

from config import *

from metrics import evaluate_model
from plots import generate_all_plots
from report_generator import generate_reports


# =====================================================
# Main
# =====================================================

def main():

    print("=" * 60)
    print("MODEL EVALUATION")
    print("=" * 60)

    print("\nLoading Dataset...")

    df = pd.read_csv(DATASET)

    print("Rows :", len(df))

    print("\nLoading Model...")

    model = joblib.load(MODEL)

    print("Model Loaded Successfully")

    # -------------------------------------------------

    X = df[FEATURES]

    y_true = df["Attack"]

    # Convert to Binary

    y_true = y_true.apply(

        lambda x: 0 if x == 0 else 1

    )

    print("\nPredicting...")

    prediction = model.predict(X)

    y_pred = [

        0 if p == 1 else 1

        for p in prediction

    ]

    print("Prediction Completed")

    # -------------------------------------------------

    print("\nCalculating Metrics...")

    metrics = evaluate_model(

        y_true,

        y_pred

    )

    # -------------------------------------------------

    print("\nGenerating Graphs...")

    generate_all_plots(

        df,

        y_true,

        y_pred

    )

    # -------------------------------------------------

    print("\nSaving Reports...")

    generate_reports(

        metrics,

        y_true,

        y_pred

    )

    print("\nEvaluation Completed Successfully")

    print("=" * 60)


# =====================================================

if __name__ == "__main__":

    main()