"""
-------------------------------------------------------
Hybrid Evaluation V2

Evaluates the complete Secure Human Workability Index
pipeline including:

1. Replay Detector
2. Isolation Forest
3. FDI Detector
4. Rule Engine
5. Hybrid Decision Fusion

Author : Sai Siddhartha
-------------------------------------------------------
"""

import os
import sys
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix
)

# =====================================================
# Project Root
# =====================================================

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

sys.path.insert(0, PROJECT_ROOT)

# =====================================================
# Project Modules
# =====================================================

from detection.rule_engine import RuleEngine
from detection.decision_fusion import DecisionFusion
from detection.temporal_detector import TemporalDetector
from detection.fdi_detector import FDIDetector

from models.predict_attack import predict_attack

# =====================================================
# Paths
# =====================================================

DATASET_PATH = os.path.join(
    PROJECT_ROOT,
    "synthetic_dataset",
    "engineered_dataset.csv"
)

RESULTS_DIR = os.path.join(
    PROJECT_ROOT,
    "results"
)

os.makedirs(RESULTS_DIR, exist_ok=True)

# =====================================================
# Metric Function
# =====================================================

def calculate_metrics(y_true, y_pred):

    try:
        auc = roc_auc_score(y_true, y_pred)
    except ValueError:
        auc = 0

    return {
        "Accuracy": accuracy_score(y_true, y_pred),
        "Precision": precision_score(
            y_true,
            y_pred,
            zero_division=0
        ),
        "Recall": recall_score(
            y_true,
            y_pred,
            zero_division=0
        ),
        "F1 Score": f1_score(
            y_true,
            y_pred,
            zero_division=0
        ),
        "ROC AUC": auc
    }


# =====================================================
# Main
# =====================================================

def main():

    print("=" * 70)
    print("SECURE HWI COMPLETE EVALUATION")
    print("=" * 70)

    print("\nLoading Dataset...")

    df = pd.read_csv(DATASET_PATH)
    
    print("\nColumns:")
    print(df.columns.tolist())

    print("Rows :", len(df))

    # Binary Ground Truth
    y_true = (
        df["Attack"]
        .apply(lambda x: 0 if x == 0 else 1)
        .tolist()
    )

    print("\nInitializing Modules...")

    rule_engine = RuleEngine()
    temporal_detector = TemporalDetector()
    fdi_detector = FDIDetector()
    fusion_engine = DecisionFusion()

    # -------------------------------------------------
    # Isolation Forest
    # -------------------------------------------------

    print("\nRunning Isolation Forest...")

    ml_df = predict_attack(df.copy())

    ml_predictions_text = ml_df["Prediction"].tolist()

    ml_predictions = [
        1 if p == "Attack" else 0
        for p in ml_predictions_text
    ]

    print("Isolation Forest Completed")

    # -------------------------------------------------
    # Evaluation Loop
    # -------------------------------------------------

    print("\nRunning Rule Engine + FDI + Hybrid Fusion...")

    history_df = pd.DataFrame()

    rule_predictions = []
    fdi_predictions = []
    hybrid_predictions = []
    hybrid_attack_types = []
    # -------------------------------------------------
    # Process Each Record
    # -------------------------------------------------

    for idx, row in df.iterrows():

        # Build history for FDI detector
        history_df = df.iloc[:idx]

        # ---------------------------------------------
        # Replay Detector (Live Evaluation Only)
        # ---------------------------------------------

        replay_result = temporal_detector.evaluate(row)

        # ---------------------------------------------
        # Rule Engine
        # ---------------------------------------------

        rule_result = rule_engine.evaluate(row)

        if len(rule_result) > 0:
            rule_predictions.append(1)
        else:
            rule_predictions.append(0)

        # ---------------------------------------------
        # Isolation Forest Result
        # ---------------------------------------------

        ml_prediction = ml_predictions_text[idx]

        isolation_anomaly = (
            ml_prediction == "Attack"
        )

        # ---------------------------------------------
        # Weather Data
        # ---------------------------------------------

        weather_data = {}

        # ---------------------------------------------
        # False Data Injection Detector
        # ---------------------------------------------

        fdi_result = fdi_detector.evaluate(
            sensor_row=row,
            history_df=history_df,
            weather_data=weather_data,
            isolation_anomaly=isolation_anomaly
        )
        
        if fdi_result["FDI"]:
            fdi_predictions.append(1)
        else:
            fdi_predictions.append(0)

        # ---------------------------------------------
        # Hybrid Decision Fusion
        # ---------------------------------------------

        decision = fusion_engine.fuse(
            rule_result=rule_result,
            ml_prediction=ml_prediction,
            fdi_result=fdi_result
        )

        if decision["AttackDetected"]:
            hybrid_predictions.append(1)
        else:
            hybrid_predictions.append(0)

        hybrid_attack_types.append(
            decision["AttackType"]
        )

    print("Hybrid Evaluation Completed")
    # =====================================================
    # Calculate Performance Metrics
    # =====================================================

    isolation_metrics = calculate_metrics(
        y_true,
        ml_predictions
    )

    rule_metrics = calculate_metrics(
        y_true,
        rule_predictions
    )

    fdi_metrics = calculate_metrics(
        y_true,
        fdi_predictions
    )

    hybrid_metrics = calculate_metrics(
        y_true,
        hybrid_predictions
    )

    # =====================================================
    # Create Results Table
    # =====================================================

    results = pd.DataFrame({

        "Model": [
            "Isolation Forest",
            "Rule Engine",
            "FDI Detector",
            "Hybrid Decision Fusion"
        ],

        "Accuracy": [
            isolation_metrics["Accuracy"],
            rule_metrics["Accuracy"],
            fdi_metrics["Accuracy"],
            hybrid_metrics["Accuracy"]
        ],

        "Precision": [
            isolation_metrics["Precision"],
            rule_metrics["Precision"],
            fdi_metrics["Precision"],
            hybrid_metrics["Precision"]
        ],

        "Recall": [
            isolation_metrics["Recall"],
            rule_metrics["Recall"],
            fdi_metrics["Recall"],
            hybrid_metrics["Recall"]
        ],

        "F1 Score": [
            isolation_metrics["F1 Score"],
            rule_metrics["F1 Score"],
            fdi_metrics["F1 Score"],
            hybrid_metrics["F1 Score"]
        ],

        "ROC AUC": [
            isolation_metrics["ROC AUC"],
            rule_metrics["ROC AUC"],
            fdi_metrics["ROC AUC"],
            hybrid_metrics["ROC AUC"]
        ]
    })

    # =====================================================
    # Display Results
    # =====================================================

    print("\n" + "=" * 70)
    print("MODEL COMPARISON")
    print("=" * 70)

    print(
        results.to_string(
            index=False,
            float_format=lambda x: f"{x:.4f}"
        )
    )

    # =====================================================
    # Confusion Matrices
    # =====================================================

    print("\nIsolation Forest Confusion Matrix")
    print(confusion_matrix(
        y_true,
        ml_predictions
    ))

    print("\nRule Engine Confusion Matrix")
    print(confusion_matrix(
        y_true,
        rule_predictions
    ))

    print("\nFDI Detector Confusion Matrix")
    print(confusion_matrix(
        y_true,
        fdi_predictions
    ))

    print("\nHybrid Decision Fusion Confusion Matrix")
    print(confusion_matrix(
        y_true,
        hybrid_predictions
    ))
    # =====================================================
    # Save Comparison Table
    # =====================================================

    comparison_csv = os.path.join(
        RESULTS_DIR,
        "hybrid_model_comparison_v2.csv"
    )

    results.to_csv(
        comparison_csv,
        index=False
    )

    # =====================================================
    # Save Detailed Predictions
    # =====================================================

    prediction_results = df.copy()

    prediction_results["GroundTruth"] = y_true

    prediction_results["IsolationForest"] = ml_predictions

    prediction_results["RuleEngine"] = rule_predictions

    prediction_results["FDIDetector"] = fdi_predictions

    prediction_results["HybridPrediction"] = hybrid_predictions

    prediction_results["HybridAttackType"] = hybrid_attack_types

    predictions_csv = os.path.join(
        RESULTS_DIR,
        "hybrid_predictions_v2.csv"
    )

    prediction_results.to_csv(
        predictions_csv,
        index=False
    )

    # =====================================================
    # Comparison Graph
    # =====================================================

    metrics_to_plot = [
        "Accuracy",
        "Precision",
        "Recall",
        "F1 Score",
        "ROC AUC"
    ]

    plot_data = results.set_index(
        "Model"
    )[metrics_to_plot].T

    ax = plot_data.plot(
        kind="bar",
        figsize=(12, 6)
    )

    plt.title(
        "Comparison of Cyberattack Detection Models"
    )

    plt.xlabel("Evaluation Metric")

    plt.ylabel("Score")

    plt.ylim(0, 1)

    plt.xticks(rotation=0)

    plt.grid(
        axis="y",
        alpha=0.3
    )

    plt.legend(
        title="Model"
    )

    plt.tight_layout()

    graph_path = os.path.join(
        RESULTS_DIR,
        "hybrid_model_comparison_v2.png"
    )

    plt.savefig(
        graph_path,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()

    # =====================================================
    # Summary
    # =====================================================

    print("\n" + "=" * 70)
    print("FILES GENERATED")
    print("=" * 70)

    print(f"Comparison CSV : {comparison_csv}")
    print(f"Predictions CSV: {predictions_csv}")
    print(f"Comparison Plot: {graph_path}")

    print("\nEvaluation Completed Successfully!")

    print("=" * 70)


# =====================================================
# Run
# =====================================================

if __name__ == "__main__":
    main()