"""
-------------------------------------------------------
Evaluation Configuration

Author : Sai Siddhartha
-------------------------------------------------------
"""

import os

# =====================================================
# Paths
# =====================================================

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DATASET = os.path.join(
    BASE_DIR,
    "synthetic_dataset",
    "engineered_dataset.csv"
)

MODEL = os.path.join(
    BASE_DIR,
    "models",
    "isolation_forest.pkl"
)

RESULTS = os.path.join(
    BASE_DIR,
    "results"
)

# Create results folder if it does not exist
os.makedirs(RESULTS, exist_ok=True)

# =====================================================
# Features used during training
# =====================================================

FEATURES = [

    "Temperature(°C)",

    "Humidity(%)",

    "Pressure(hPa)",

    "TempRate",

    "HumidityRate",

    "PressureRate",

    "RollingMeanTemp",

    "RollingStdTemp",

    "ConstantTemp"

]