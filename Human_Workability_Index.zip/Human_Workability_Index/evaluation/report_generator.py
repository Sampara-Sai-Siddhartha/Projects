"""
-------------------------------------------------------
Report Generator

Saves:
1. Metrics Summary
2. Evaluation Summary

Author : Sai Siddhartha
-------------------------------------------------------
"""

import os
import pandas as pd

from sklearn.metrics import classification_report

from config import RESULTS


def generate_reports(metrics, y_true, y_pred):

    print("Generating Reports...")

    # ============================================
    # Performance Metrics CSV
    # ============================================

    performance = pd.DataFrame({

        "Metric":[
            "Accuracy",
            "Precision",
            "Recall",
            "F1 Score",
            "ROC AUC"
        ],

        "Value":[

            metrics["Accuracy"],

            metrics["Precision"],

            metrics["Recall"],

            metrics["F1 Score"],

            metrics["ROC AUC"]

        ]

    })

    performance.to_csv(

        os.path.join(

            RESULTS,

            "performance_metrics.csv"

        ),

        index=False

    )

    # ============================================
    # Classification Report
    # ============================================

    report = classification_report(

        y_true,

        y_pred,

        output_dict=True,

        zero_division=0

    )

    report_df = pd.DataFrame(report).transpose()

    report_df.to_csv(

        os.path.join(

            RESULTS,

            "classification_report.csv"

        )

    )

    # ============================================
    # Text Summary
    # ============================================

    summary = os.path.join(

        RESULTS,

        "evaluation_summary.txt"

    )

    with open(summary, "w") as f:

        f.write("="*60 + "\n")

        f.write("MODEL EVALUATION SUMMARY\n")

        f.write("="*60 + "\n\n")

        for key in [

            "Accuracy",

            "Precision",

            "Recall",

            "F1 Score",

            "ROC AUC"

        ]:

            f.write(f"{key:15s}: {metrics[key]:.4f}\n")

        f.write("\n")

        f.write("Evaluation Completed Successfully.\n")

    print("Reports Saved Successfully.")
    