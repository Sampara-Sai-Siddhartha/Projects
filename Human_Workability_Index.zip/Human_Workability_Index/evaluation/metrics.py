"""
-------------------------------------------------------
Evaluation Metrics

Calculates:

1. Accuracy
2. Precision
3. Recall
4. F1 Score
5. ROC AUC
6. Confusion Matrix
7. Classification Report

Author : Sai Siddhartha
-------------------------------------------------------
"""

import os
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report
)

from config import RESULTS


# =====================================================
# Evaluate Model
# =====================================================

def evaluate_model(y_true, y_pred):

    accuracy = accuracy_score(y_true, y_pred)

    precision = precision_score(
        y_true,
        y_pred,
        zero_division=0
    )

    recall = recall_score(
        y_true,
        y_pred,
        zero_division=0
    )

    f1 = f1_score(
        y_true,
        y_pred,
        zero_division=0
    )

    try:
        auc = roc_auc_score(
            y_true,
            y_pred
        )
    except:
        auc = 0

    cm = confusion_matrix(
        y_true,
        y_pred
    )

    report = classification_report(
        y_true,
        y_pred,
        output_dict=True,
        zero_division=0
    )

    # ----------------------------------------
    # Print Results
    # ----------------------------------------

    print("\n===============================")
    print("Evaluation Metrics")
    print("===============================")

    print(f"Accuracy  : {accuracy:.4f}")
    print(f"Precision : {precision:.4f}")
    print(f"Recall    : {recall:.4f}")
    print(f"F1 Score  : {f1:.4f}")
    print(f"ROC AUC   : {auc:.4f}")

    print("\nConfusion Matrix")

    print(cm)

    # ----------------------------------------
    # Save Metrics CSV
    # ----------------------------------------

    metrics_df = pd.DataFrame({

        "Metric":[
            "Accuracy",
            "Precision",
            "Recall",
            "F1 Score",
            "ROC AUC"
        ],

        "Value":[
            accuracy,
            precision,
            recall,
            f1,
            auc
        ]

    })

    metrics_df.to_csv(

        os.path.join(
            RESULTS,
            "performance_metrics.csv"
        ),

        index=False

    )

    # ----------------------------------------
    # Save Classification Report
    # ----------------------------------------

    report_df = pd.DataFrame(report).transpose()

    report_df.to_csv(

        os.path.join(
            RESULTS,
            "classification_report.csv"
        )

    )

    return {

        "Accuracy": accuracy,

        "Precision": precision,

        "Recall": recall,

        "F1 Score": f1,

        "ROC AUC": auc,

        "Confusion Matrix": cm,

        "Classification Report": report

    }