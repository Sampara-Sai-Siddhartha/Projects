import pandas as pd
from config import SHEET_ID

CSV_URL = f"https://docs.google.com/spreadsheets/d/{SHEET_ID}/export?format=csv"


def read_sheet():
    return pd.read_csv(CSV_URL)


def get_latest_sensor_data():
    df = read_sheet()
    return df.iloc[-1]


if __name__ == "__main__":

    latest = get_latest_sensor_data()

    print("\nLatest Sensor Data\n")
    print(latest)