// ======================================================
// Secure Human Workability Index Dashboard
// ======================================================

// Store the last trusted state
let lastTrustedState = null;

// ------------------------------------------------------

function updateSensor(sensor){

    document.getElementById("sensor_temp").innerHTML =
        sensor["Temperature(°C)"] + " °C";

    document.getElementById("sensor_humidity").innerHTML =
        sensor["Humidity(%)"] + " %";

    document.getElementById("sensor_pressure").innerHTML =
        sensor["Pressure(hPa)"] + " hPa";

    document.getElementById("sensor_aqi").innerHTML =
        sensor["AQI"];

    document.getElementById("sensor_gas").innerHTML =
        sensor["Gas (kOhms)"] + " kΩ";

    document.getElementById("sensor_heatindex").innerHTML =
        sensor["HeatIndex(°C)"] + " °C";

}

// ------------------------------------------------------

function updateWeather(weather){

    document.getElementById("weather_temp").innerHTML =
        weather["Temperature"] + " °C";

    document.getElementById("weather_humidity").innerHTML =
        weather["Humidity"] + " %";

    document.getElementById("weather_pressure").innerHTML =
        weather["Pressure"] + " hPa";

    document.getElementById("weather_condition").innerHTML =
        weather["Weather"];

    document.getElementById("weather_wind").innerHTML =
        weather["Wind Speed"] + " km/h";

}

// ------------------------------------------------------

function updateHWI(hwi){

    document.getElementById("hwi_score").innerHTML =
        hwi["HWI"];

    document.getElementById("physical_capacity").innerHTML =
        hwi["Physical Capacity"];

    document.getElementById("mental_focus").innerHTML =
        hwi["Mental Focus"];

    document.getElementById("heat_stress").innerHTML =
        hwi["Heat Stress"];

    document.getElementById("fatigue_risk").innerHTML =
        hwi["Fatigue Risk"];

    // Status

    let score = Number(hwi["HWI"]);

    let status = "";

    if(score >= 85)
        status = "Excellent";

    else if(score >= 70)
        status = "Good";

    else if(score >= 50)
        status = "Moderate";

    else
        status = "Poor";

    document.getElementById("hwi_status").innerHTML = status;

}

// ------------------------------------------------------

function updateAttack(data){

    let status = document.getElementById("attack_status");

    let list = document.getElementById("attack_list");

    list.innerHTML = "";

    if(data.AttackDetected){

        status.innerHTML = "⚠ ATTACK DETECTED";

        status.className = "status-attack";

        if(data.AttackTypes.length===0){

            list.innerHTML="<li>Unknown Attack</li>";

        }else{

            data.AttackTypes.forEach(function(a){

                list.innerHTML +=
                    "<li>"+a+"</li>";

            });

        }

    }

    else{

        status.innerHTML="✔ SENSOR TRUSTED";

        status.className="status-normal";

        list.innerHTML="<li>No Active Attack</li>";

    }

    document.getElementById("attack_confidence").innerHTML =
        data.Confidence+" %";

}

// ------------------------------------------------------

function freezeDashboard(timestamp){

    document.querySelectorAll(".card")
        .forEach(function(card){

            card.classList.add("card-freeze");

        });

    document.getElementById("recommendation").innerHTML =

        "⚠ SECURITY WARNING<br>" +

        "Displaying Last Verified HWI<br><br>" +

        "Last Verified : "+timestamp;

}

// ------------------------------------------------------

function unfreezeDashboard(){

    document.querySelectorAll(".card")
        .forEach(function(card){

            card.classList.remove("card-freeze");

        });

}

// ------------------------------------------------------

async function loadData(){

    try{

        const response =
            await fetch("/api/data");

        const data =
            await response.json();

        document.getElementById("timestamp").innerHTML =
            data.timestamp;

        updateSensor(data.sensor);

        updateWeather(data.weather);

        updateAttack(data.attack);

        // ==========================
        // Trusted Sensor
        // ==========================

        if(!data.attack.AttackDetected){

            lastTrustedState = {

                hwi:data.hwi,

                recommendation:data.recommendation,

                timestamp:data.timestamp

            };
            
            if(data.hwi != null){

                updateHWI(data.hwi);

            }

            document.getElementById("recommendation")
                .innerHTML =
                data.recommendation;

            unfreezeDashboard();

        }

        // ==========================
        // Attack Detected
        // ==========================

        else{

            if(lastTrustedState!=null){

                updateHWI(lastTrustedState.hwi);

                freezeDashboard(lastTrustedState.timestamp);

            }

        }

    }

    catch(error){

        console.log(error);

    }

}

// ------------------------------------------------------

loadData();

setInterval(loadData,5000);