import requests

from config import (
    OPENWEATHER_API_KEY,
    LATITUDE,
    LONGITUDE
)

URL = "https://api.openweathermap.org/data/2.5/weather"


def get_weather_data():

    params = {
        "lat": LATITUDE,
        "lon": LONGITUDE,
        "appid": OPENWEATHER_API_KEY,
        "units": "metric"
    }

    response = requests.get(URL, params=params, timeout=10)

    response.raise_for_status()

    data = response.json()

    weather = {
        "Temperature": data["main"]["temp"],
        "Humidity": data["main"]["humidity"],
        "Pressure": data["main"]["pressure"],
        "Weather": data["weather"][0]["description"],
        "Wind Speed": data["wind"]["speed"]
    }

    return weather


if __name__ == "__main__":

    weather = get_weather_data()
    
    print(weather)
    
    print("\nTrusted Weather Data\n")

    for key, value in weather.items():
        print(f"{key}: {value}")