from weather_api import get_weather
from attack_detection import detect_attack

sensor = {
    "Temperature": 34.0,
    "Humidity": 66.0,
    "Pressure": 1006.1
}

api = get_weather()

report = detect_attack(sensor, api)

print("\nSensor Data")
print(sensor)

print("\nTrusted API")
print(api)

print("\nVerification")

for key, value in report.items():
    print(f"{key}: {value}")