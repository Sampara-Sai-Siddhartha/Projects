"""
-------------------------------------------------------
Live Feature Engineering

Creates ML features from incoming live sensor data.

Improved Version:
- Rate Features
- Rolling Statistics
- Consecutive Constant Temperature Counter
- Backward Compatible with Isolation Forest

Author : Sai Siddhartha
-------------------------------------------------------
"""

import pandas as pd


class LiveFeatureEngineering:

    def __init__(self):

        self.previous = None

        # Counts consecutive identical temperatures
        self.constant_temp_count = 0
        self.constant_humidity_count = 0
        self.constant_pressure_count = 0

    # --------------------------------------------------

    def transform(self, sensor):

        features = {}

        # --------------------------------------------------
        # Raw Features
        # --------------------------------------------------

        features["Temperature(°C)"] = sensor["Temperature(°C)"]
        features["Humidity(%)"] = sensor["Humidity(%)"]
        features["Pressure(hPa)"] = sensor["Pressure(hPa)"]

        # --------------------------------------------------
        # First Reading
        # --------------------------------------------------

        if self.previous is None:

            features["TempRate"] = 0
            features["HumidityRate"] = 0
            features["PressureRate"] = 0

            features["RollingMeanTemp"] = sensor["Temperature(°C)"]
            features["RollingStdTemp"] = 0

            self.constant_temp_count = 0

            # Backward compatibility for Isolation Forest
            features["ConstantTemp"] = 0

            # New feature for Rule Engine
            features["ConstantTempCount"] = 0

        else:

            # -----------------------------
            # Rate Features
            # -----------------------------

            features["TempRate"] = (
                sensor["Temperature(°C)"]
                - self.previous["Temperature(°C)"]
            )

            features["HumidityRate"] = (
                sensor["Humidity(%)"]
                - self.previous["Humidity(%)"]
            )

            features["PressureRate"] = (
                sensor["Pressure(hPa)"]
                - self.previous["Pressure(hPa)"]
            )

            # -----------------------------
            # Rolling Statistics
            # -----------------------------

            features["RollingMeanTemp"] = (
                sensor["Temperature(°C)"]
                + self.previous["Temperature(°C)"]
            ) / 2

            features["RollingStdTemp"] = abs(
                sensor["Temperature(°C)"]
                - self.previous["Temperature(°C)"]
            )

            # -----------------------------
            # Frozen Sensor Counter
            # -----------------------------

            if (
                sensor["Temperature(°C)"]
                == self.previous["Temperature(°C)"]
            ):

                self.constant_temp_count += 1

            else:

                self.constant_temp_count = 0
            
            # Humidity Counter
            if sensor["Humidity(%)"] == self.previous["Humidity(%)"]:
                self.constant_humidity_count += 1
            else:
                self.constant_humidity_count = 0

            # Pressure Counter
            if sensor["Pressure(hPa)"] == self.previous["Pressure(hPa)"]:
                self.constant_pressure_count += 1
            else:
                self.constant_pressure_count = 0

            # Old feature (Isolation Forest compatibility)
            features["ConstantTemp"] = int(
                self.constant_temp_count > 0
            )

            # New feature (Rule Engine)
            features["ConstantTempCount"] = self.constant_temp_count
            features["ConstantHumidityCount"] = self.constant_humidity_count
            features["ConstantPressureCount"] = self.constant_pressure_count

        # --------------------------------------------------
        # Save Current Reading
        # --------------------------------------------------

        self.previous = sensor.copy()

        return pd.DataFrame([features])