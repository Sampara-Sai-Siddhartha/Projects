"""
-------------------------------------------------------
Feature Engineering Module
-------------------------------------------------------

Creates machine learning and rule-based features
from the synthetic cyberattack dataset.

Author : Sai Siddhartha
Project : Secure Human Workability Index
-------------------------------------------------------
"""

import pandas as pd

# ==========================================================
# File Paths
# ==========================================================

INPUT_FILE = "synthetic_dataset/synthetic_attack_dataset.csv"
OUTPUT_FILE = "synthetic_dataset/engineered_dataset.csv"


# ==========================================================
# Feature Engineering
# ==========================================================

def create_features(df):

    print("\nCreating Engineered Features...")

    # ------------------------------------------
    # Previous Sensor Values
    # ------------------------------------------

    df["PrevTemp"] = df["Temperature(°C)"].shift(1)
    df["PrevHumidity"] = df["Humidity(%)"].shift(1)
    df["PrevPressure"] = df["Pressure(hPa)"].shift(1)

    # ------------------------------------------
    # Rate of Change
    # ------------------------------------------

    df["TempRate"] = (
        df["Temperature(°C)"] - df["PrevTemp"]
    )

    df["HumidityRate"] = (
        df["Humidity(%)"] - df["PrevHumidity"]
    )

    df["PressureRate"] = (
        df["Pressure(hPa)"] - df["PrevPressure"]
    )

    # ------------------------------------------
    # Rolling Mean
    # ------------------------------------------

    df["RollingMeanTemp"] = (
        df["Temperature(°C)"]
        .rolling(window=5)
        .mean()
    )

    df["RollingMeanHumidity"] = (
        df["Humidity(%)"]
        .rolling(window=5)
        .mean()
    )

    # ------------------------------------------
    # Rolling Standard Deviation
    # ------------------------------------------

    df["RollingStdTemp"] = (
        df["Temperature(°C)"]
        .rolling(window=5)
        .std()
    )

    df["RollingStdHumidity"] = (
        df["Humidity(%)"]
        .rolling(window=5)
        .std()
    )

    # ------------------------------------------
    # Constant Value Features   
    # ------------------------------------------

    def consecutive_count(series):
        counts = []
        count = 0
        prev = None

        for value in series:
            if prev is not None and value == prev:
                count += 1
            else:
                count = 0

            counts.append(count)
            prev = value

        return counts


    # Temperature
    df["ConstantTemp"] = (
        df["Temperature(°C)"]
        .eq(df["Temperature(°C)"].shift())
        .astype(int)
    )

    df["ConstantTempCount"] = consecutive_count(
        df["Temperature(°C)"]
    )

    # Humidity
    df["ConstantHumidityCount"] = consecutive_count(
        df["Humidity(%)"]
    )

    # Pressure
    df["ConstantPressureCount"] = consecutive_count(
        df["Pressure(hPa)"]
    )
    
    # ------------------------------------------
    # Missing Value Flag
    # ------------------------------------------

    df["MissingFlag"] = (
        df["Temperature(°C)"]
        .isna()
        .astype(int)
    )

    # ------------------------------------------
    # Duplicate Flag
    # Useful for Replay Detection
    # ------------------------------------------

    df["DuplicateFlag"] = (
        df.duplicated().astype(int)
    )

    # ------------------------------------------
    # Fill Missing Values
    # ------------------------------------------

    df = df.bfill()
    df = df.ffill()

    return df


# ==========================================================
# Main Function
# ==========================================================

def main():

    print("=" * 60)
    print("FEATURE ENGINEERING MODULE")
    print("=" * 60)

    df = pd.read_csv(INPUT_FILE)

    print(f"\nRows Loaded : {len(df)}")

    df = create_features(df)

    df.to_csv(OUTPUT_FILE, index=False)

    print("\nEngineered Dataset Saved Successfully!")

    print(f"\nOutput File : {OUTPUT_FILE}")

    print("=" * 60)


# ==========================================================
# Driver Code
# ==========================================================

if __name__ == "__main__":
    main()