import pandas as pd

INPUT_FILE = "data/aerosense_raw.xlsx"
OUTPUT_FILE = "data/aerosense_base.csv"


def clean_dataset(df):

    # Remove duplicate rows
    df = df.drop_duplicates()

    # Remove empty rows
    df = df.dropna()

    # Reset index
    df = df.reset_index(drop=True)

    return df


def add_timestamp(df):

    df["Timestamp"] = pd.to_datetime(
        df["Date"].astype(str) + " " + df["Time"].astype(str)
    )

    return df


def add_sequence(df):

    df["Sequence"] = range(1, len(df) + 1)

    return df


def main():

    print("Loading AeroSense dataset...")

    df = pd.read_excel(INPUT_FILE)

    print(f"Original Rows : {len(df)}")

    df = clean_dataset(df)

    df = add_timestamp(df)

    df = add_sequence(df)

    print(f"Clean Rows : {len(df)}")

    df.to_csv(OUTPUT_FILE, index=False)

    print("Base dataset created successfully.")

    print(df.head())


if __name__ == "__main__":
    main()