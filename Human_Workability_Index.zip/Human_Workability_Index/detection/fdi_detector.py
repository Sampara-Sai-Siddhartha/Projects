"""
-------------------------------------------------------
False Data Injection Detector

Combines:
1. Isolation Forest
2. Historical Behaviour
3. Weather Validation

Author : Sai Siddhartha
-------------------------------------------------------
"""

import pandas as pd
import numpy as np


class FDIDetector:

    def __init__(self):

        # Weather tolerances
        self.weather_limits = {
            "Temperature": 2.0,
            "Humidity": 15,
            "Pressure": 5
        }

        # History parameters
        self.window_size = 10
        self.z_threshold = 3.0
        
        # Evidence weights
        self.weights = {
            "isolation": 40,
            "history": 10,
            "weather": 10
        }
    
    # -------------------------------------------------
    # Historical Behaviour
    # -------------------------------------------------

    def historical_analysis(self, sensor_row, history_df):

        score = 0
        reasons = []

        if len(history_df) < self.window_size:
            return score, reasons

        history = history_df.tail(self.window_size)

        columns = [
            "Temperature(°C)",
            "Humidity(%)",
            "Pressure(hPa)"
        ]

        for column in columns:

            mean = history[column].mean()
            std = history[column].std()

            value = sensor_row[column]

            # Handle constant history
            if std == 0:

                if abs(value - mean) > 1:

                    score += self.weights["history"]

                    reasons.append(
                        f"{column} deviates from constant history"
                    )

                continue

            z_score = abs(value - mean) / std

            if z_score > self.z_threshold:

                score += self.weights["history"]

                reasons.append(
                    f"{column} deviates from history"
                )

        return score, reasons
    
    # -------------------------------------------------
    # Weather Validation
    # -------------------------------------------------

    def weather_validation(self, sensor_row, weather_data):

        score = 0
        reasons = []

        comparisons = [
            ("Temperature(°C)", "Temperature"),
            ("Humidity(%)", "Humidity"),
            ("Pressure(hPa)", "Pressure")
        ]

        for sensor_col, weather_col in comparisons:

            if weather_col not in weather_data:
                continue

            sensor_value = sensor_row[sensor_col]
            weather_value = weather_data[weather_col]

            difference = abs(sensor_value - weather_value)

            threshold = self.weather_limits[weather_col]

            if difference > threshold:

                score += self.weights["weather"]

                reasons.append(
                    f"{weather_col} mismatch "
                    f"(Sensor={sensor_value}, "
                    f"Weather={weather_value})"
                )

        return score, reasons

    # -------------------------------------------------
    # Main Evaluation
    # -------------------------------------------------

    def evaluate(
        self,
        sensor_row,
        history_df,
        weather_data,
        isolation_anomaly
    ):

        result = {

            "FDI": False,
            "FDIScore": 0,
            "Confidence": "Low",
            "Reasons": []

        }

        # ---------------------------------------------
        # Isolation Forest Evidence
        # ---------------------------------------------

        if isolation_anomaly:

            result["FDIScore"] += self.weights["isolation"]

            result["Reasons"].append(
                "Isolation Forest detected anomaly"
            )

        # ---------------------------------------------
        # Historical Behaviour
        # ---------------------------------------------

        history_score, history_reasons = self.historical_analysis(
            sensor_row,
            history_df
        )

        result["FDIScore"] += history_score
        result["Reasons"].extend(history_reasons)

        # ---------------------------------------------
        # Weather Validation
        # ---------------------------------------------

        weather_score, weather_reasons = self.weather_validation(
            sensor_row,
            weather_data
        )

        result["FDIScore"] += weather_score
        result["Reasons"].extend(weather_reasons)

        # ---------------------------------------------
        # Final Decision
        # ---------------------------------------------
        
        score = result["FDIScore"]

        if score >= 40:

            result["FDI"] = True
            result["Confidence"] = "High"

        elif score >= 30:

            result["FDI"] = False
            result["Confidence"] = "Medium"

        else:

            result["FDI"] = False
            result["Confidence"] = "Low"

        if len(result["Reasons"]) == 0:

            result["Reasons"].append("Normal")

        return result