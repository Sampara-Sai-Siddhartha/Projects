"""
-------------------------------------------------------
Rule Engine

Deterministic Cyber Attack Detection

Detects:

1. Missing Data
2. Out Of Range
3. Sudden Spike
4. Frozen Sensor

Author : Sai Siddhartha
-------------------------------------------------------
"""

import pandas as pd


class RuleEngine:

    def __init__(self):

        # -----------------------------
        # Sensor Limits
        # -----------------------------

        self.temp_min = -20
        self.temp_max = 60

        self.humidity_min = 0
        self.humidity_max = 100

        self.pressure_min = 850
        self.pressure_max = 1100

        # -----------------------------
        # Detection Thresholds
        # -----------------------------

        self.spike_threshold = 8

        # Number of consecutive identical readings
        self.freeze_window = 10

    # --------------------------------------------------

    def detect_missing(self, row):

        return row.isnull().any()

    # --------------------------------------------------

    def detect_out_of_range(self, row):

        if (
            row["Temperature(°C)"] < self.temp_min
            or row["Temperature(°C)"] > self.temp_max
        ):
            return True

        if (
            row["Humidity(%)"] < self.humidity_min
            or row["Humidity(%)"] > self.humidity_max
        ):
            return True

        if (
            row["Pressure(hPa)"] < self.pressure_min
            or row["Pressure(hPa)"] > self.pressure_max
        ):
            return True

        return False

    # --------------------------------------------------

    def detect_spike(self, row):

        return abs(row["TempRate"]) > self.spike_threshold

    # --------------------------------------------------
    def detect_frozen(self, row):

        required = [
            "ConstantTempCount",
            "TempRate",
            "HumidityRate",
            "PressureRate"
        ]

        for feature in required:
            if feature not in row.index or pd.isna(row[feature]):
                return False

        if (
            row["ConstantTempCount"] >= self.freeze_window and
            abs(row["TempRate"]) < 0.01 and
            abs(row["HumidityRate"]) < 0.01 and
            abs(row["PressureRate"]) < 0.01
        ):
            return True

        return False
    # --------------------------------------------------

    def evaluate(self, row):

        attacks = []

        if self.detect_missing(row):
            attacks.append("Missing Data")

        if self.detect_out_of_range(row):
            attacks.append("Out Of Range")

        if self.detect_spike(row):
            attacks.append("Sudden Spike")

        if self.detect_frozen(row):
            attacks.append("Frozen Sensor")

        return attacks