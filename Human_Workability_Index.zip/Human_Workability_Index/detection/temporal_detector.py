"""
-------------------------------------------------------
Temporal Detector (Version 2)

Detects:
1. Duplicate Polling
2. Timestamp Rollback
3. Duplicate Timestamp
4. Duplicate Sensor Packet

Uses Multi-Evidence Replay Detection.

Author : Sai Siddhartha
-------------------------------------------------------
"""

from datetime import datetime
import hashlib


class TemporalDetector:

    def __init__(self):

        self.last_row_index = None
        self.last_timestamp = None

        self.timestamp_history = set()
        self.packet_history = set()

    # -------------------------------------------------
    # Build Timestamp
    # -------------------------------------------------

    def build_timestamp(self, row):

        try:

            return datetime.strptime(
                f"{row['Date']} {row['Time']}",
                "%Y-%m-%d %H:%M:%S"
            )

        except Exception:

            return None

    # -------------------------------------------------
    # Packet Signature
    # -------------------------------------------------

    def packet_signature(self, row):

        packet = (
            str(row["Temperature(°C)"]) +
            str(row["Humidity(%)"]) +
            str(row["Pressure(hPa)"]) +
            str(row["AQI"]) +
            str(row["Gas (kOhms)"]) +
            str(row["Altitude(m)"]) +
            str(row["DewPoint(°C)"]) +
            str(row["HeatIndex(°C)"])
        )

        return hashlib.sha256(
            packet.encode()
        ).hexdigest()

    # -------------------------------------------------
    # Evaluate
    # -------------------------------------------------

    def evaluate(self, row):

        result = {

            "ReplayAttack": False,

            "ReplayScore": 0,

            "Confidence": "Low",

            "Reasons": []

        }

        # ---------------------------------------------
        # Duplicate Polling
        # ---------------------------------------------

        if row.name == self.last_row_index:

            result["Reasons"].append(
                "No New Data"
            )

            return result

        self.last_row_index = row.name

        # ---------------------------------------------
        # Timestamp
        # ---------------------------------------------

        timestamp = self.build_timestamp(row)

        if timestamp is None:

            result["ReplayAttack"] = True

            result["ReplayScore"] += 100

            result["Reasons"].append(
                "Invalid Timestamp"
            )

            result["Confidence"] = "High"

            return result

        # ---------------------------------------------
        # Timestamp Rollback
        # ---------------------------------------------

        if self.last_timestamp is not None:

            if timestamp < self.last_timestamp:

                result["ReplayScore"] += 50

                result["Reasons"].append(
                    "Timestamp Rollback"
                )

        # ---------------------------------------------
        # Duplicate Timestamp
        # ---------------------------------------------

        if timestamp in self.timestamp_history:

            result["ReplayScore"] += 30

            result["Reasons"].append(
                "Duplicate Timestamp"
            )

        self.timestamp_history.add(timestamp)

        self.last_timestamp = timestamp

        # ---------------------------------------------
        # Duplicate Packet
        # ---------------------------------------------

        signature = self.packet_signature(row)

        if signature in self.packet_history:

            result["ReplayScore"] += 20

            result["Reasons"].append(
                "Duplicate Sensor Packet"
            )

        self.packet_history.add(signature)

        # ---------------------------------------------
        # Final Decision
        # ---------------------------------------------

        score = result["ReplayScore"]

        if score >= 70:

            result["ReplayAttack"] = True

            result["Confidence"] = "High"

        elif score >= 40:

            result["ReplayAttack"] = True

            result["Confidence"] = "Medium"

        elif score > 0:

            result["ReplayAttack"] = False

            result["Confidence"] = "Low"

        if len(result["Reasons"]) == 0:

            result["Reasons"].append(
                "Normal"
            )

        return result