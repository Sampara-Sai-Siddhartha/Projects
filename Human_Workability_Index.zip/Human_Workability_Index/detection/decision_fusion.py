"""
-------------------------------------------------------
Decision Fusion Engine

Combines

1. Rule Engine
2. Isolation Forest
3. FDI Detector

Author : Sai Siddhartha
-------------------------------------------------------
"""


class DecisionFusion:

    def __init__(self):
        pass

    def fuse(self, rule_result, ml_prediction, fdi_result):

        result = {
            "AttackDetected": False,
            "AttackType": "Normal",
            "Confidence": 0
        }

        attack_types = []

       # ---------- High confidence rules ----------
        if "Missing Data" in rule_result:
            result["AttackDetected"] = True
            result["AttackType"] = "Missing Data"
            result["Confidence"] = 100
            return result

        if "Out Of Range" in rule_result:
            result["AttackDetected"] = True
            result["AttackType"] = "Out Of Range"
            result["Confidence"] = 100
            return result

        if "Sudden Spike" in rule_result:
            result["AttackDetected"] = True
            result["AttackType"] = "Sudden Spike"
            result["Confidence"] = 95
            return result

        # ---------- Isolation Forest ----------
        ml_attack = (ml_prediction == "Attack")

        # ---------- FDI ----------
        fdi_attack = fdi_result["FDI"]

        # ---------- Frozen ----------
        frozen = "Frozen Sensor" in rule_result

        # Highest confidence
        if frozen and ml_attack:
            attack_types.extend([
                "Frozen Sensor",
                "Isolation Forest"
            ])
            result["AttackDetected"] = True
            result["Confidence"] = 90

        elif fdi_attack:
            attack_types.append("False Data Injection")
            result["AttackDetected"] = True
            result["Confidence"] = fdi_result["FDIScore"]

        elif ml_attack:
            attack_types.append("Isolation Forest")
            result["AttackDetected"] = True
            result["Confidence"] = 70

        elif frozen:
            attack_types.append("Frozen Sensor")
            result["AttackDetected"] = True
            result["Confidence"] = 60

        if attack_types:
            result["AttackType"] = ", ".join(attack_types)

        return result