"""
-------------------------------------------------------
Attack Event Model
-------------------------------------------------------

Represents a single cyberattack event.

This class is used by the Scenario Generator
and Attack Engine.

-------------------------------------------------------
"""

from dataclasses import dataclass, field
from typing import List


@dataclass
class AttackEvent:

    # Unique event id
    event_id: int

    # Attack information
    attack_id: int
    attack_name: str

    # Dataset position
    start_index: int
    duration: int

    # Attack characteristics
    intensity: str
    affected_sensors: List[str]

    # Optional metadata
    description: str = ""
    severity: str = "Medium"

    @property
    def end_index(self):
        return self.start_index + self.duration

    def __str__(self):

        return (
            f"[Event {self.event_id}] "
            f"{self.attack_name} | "
            f"Rows {self.start_index}-{self.end_index} | "
            f"Intensity={self.intensity}"
        )