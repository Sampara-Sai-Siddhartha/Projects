"""
Configuration for Attack Generator
"""

ATTACK_TYPES = {

    1: "False Data Injection",
    2: "Replay Attack",
    3: "Sensor Drift",
    4: "Sudden Spike",
    5: "Frozen Sensor",
    6: "Missing Data",
    7: "Out Of Range",
    8: "Noise Injection",
    9: "Sensor Spoofing"
}


ATTACK_PROBABILITY = {

    1: 0.15,
    2: 0.10,
    3: 0.10,
    4: 0.10,
    5: 0.10,
    6: 0.10,
    7: 0.05,
    8: 0.10,
    9: 0.05
}


MIN_DURATION = 10
MAX_DURATION = 100