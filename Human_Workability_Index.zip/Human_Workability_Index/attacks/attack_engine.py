"""
-------------------------------------------------------
Attack Engine
-------------------------------------------------------

Applies AttackEvent objects to the dataset.

Author : Sai Siddhartha
-------------------------------------------------------
"""

from attacks.attack_profiles import (
    FalseDataInjection,
    SuddenSpike,
    FrozenSensor
)


class AttackEngine:

    def __init__(self):

        # Register available attacks
        self.attack_profiles = {

            1: FalseDataInjection(),

            4: SuddenSpike(),

            5: FrozenSensor()

        }

    def apply_events(self, df, events):

        # Create columns if they don't exist
        if "Attack" not in df.columns:
            df["Attack"] = 0

        if "AttackName" not in df.columns:
            df["AttackName"] = "Normal"

        # Apply each attack
        for event in events:

            attack = self.attack_profiles.get(event.attack_id)

            if attack is None:
                print(f"Skipping unsupported attack: {event.attack_name}")
                continue

            df = attack.apply(df, event)

            print(f"Applied: {event}")

        return df