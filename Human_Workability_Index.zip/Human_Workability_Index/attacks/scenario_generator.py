"""
-------------------------------------------------------
Scenario Generator
-------------------------------------------------------

Generates realistic cyberattack scenarios.

It DOES NOT modify the dataset.

It ONLY creates AttackEvent objects.

-------------------------------------------------------
"""

import random

from attacks.attack_event import AttackEvent


ATTACK_LIBRARY = {

    1: "False Data Injection",
    2: "Replay Attack",
    3: "Sensor Drift",
    4: "Sudden Spike",
    5: "Frozen Sensor",
    6: "Missing Data",
    7: "Out Of Range",
    8: "Noise Injection",
    9: "Sensor Spoofing"

}


SENSOR_LIBRARY = [

    "Temperature(°C)",
    "Humidity(%)",
    "Pressure(hPa)",
    "AQI",
    "Gas (kOhms)",
    "HeatIndex(°C)",
    "DewPoint(°C)"

]


INTENSITY = [

    "Low",
    "Medium",
    "High"

]


class ScenarioGenerator:

    def __init__(self, dataset_size):

        self.dataset_size = dataset_size

    def generate(self, n_events=20):

        scenarios = []

        for event_id in range(1, n_events + 1):

            attack_id = random.randint(1, 9)

            duration = random.randint(20, 80)

            start = random.randint(
                0,
                self.dataset_size - duration - 1
            )

            sensors = random.sample(

                SENSOR_LIBRARY,

                random.randint(1, 3)

            )

            intensity = random.choice(INTENSITY)

            event = AttackEvent(

                event_id=event_id,

                attack_id=attack_id,

                attack_name=ATTACK_LIBRARY[attack_id],

                start_index=start,

                duration=duration,

                intensity=intensity,

                affected_sensors=sensors,

                description="Automatically generated scenario"

            )

            scenarios.append(event)

        return scenarios