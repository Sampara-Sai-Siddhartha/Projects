"""
-------------------------------------------------------
Attack Profiles
-------------------------------------------------------

Every attack receives:

1. DataFrame
2. AttackEvent

The attack only modifies the rows specified by
the event.

It NEVER decides

- start position
- duration
- probability

-------------------------------------------------------
"""

from abc import ABC, abstractmethod


# ==========================================================
# Base Class
# ==========================================================

class BaseAttack(ABC):

    @abstractmethod
    def apply(self, df, event):
        pass


# ==========================================================
# False Data Injection
# ==========================================================

class FalseDataInjection(BaseAttack):

    def apply(self, df, event):

        start = event.start_index
        end = event.end_index

        # Attack intensity
        if event.intensity == "Low":
            temp_change = 3
            humidity_change = 8

        elif event.intensity == "Medium":
            temp_change = 6
            humidity_change = 15

        else:
            temp_change = 10
            humidity_change = 25

        if "Temperature(°C)" in event.affected_sensors:

            df.loc[start:end,
                   "Temperature(°C)"] -= temp_change

        if "Humidity(%)" in event.affected_sensors:

            df.loc[start:end,
                   "Humidity(%)"] -= humidity_change

        df.loc[start:end, "Attack"] = event.attack_id
        df.loc[start:end, "AttackName"] = event.attack_name

        return df


# ==========================================================
# Sudden Spike
# ==========================================================

class SuddenSpike(BaseAttack):

    def apply(self, df, event):

        start = event.start_index
        end = event.end_index

        if event.intensity == "Low":
            spike = 8

        elif event.intensity == "Medium":
            spike = 15

        else:
            spike = 25

        for sensor in event.affected_sensors:

            if sensor in df.columns:

                df.loc[start:end, sensor] += spike

        df.loc[start:end, "Attack"] = event.attack_id
        df.loc[start:end, "AttackName"] = event.attack_name

        return df


# ==========================================================
# Frozen Sensor
# ==========================================================

class FrozenSensor(BaseAttack):

    def apply(self, df, event):

        start = event.start_index
        end = event.end_index

        for sensor in event.affected_sensors:

            if sensor in df.columns:

                value = df.loc[start, sensor]

                df.loc[start:end, sensor] = value

        df.loc[start:end, "Attack"] = event.attack_id
        df.loc[start:end, "AttackName"] = event.attack_name

        return df