from config import *

def detect_attack(sensor, api):

    temp_diff = abs(sensor["Temperature"] - api["Temperature"])
    humidity_diff = abs(sensor["Humidity"] - api["Humidity"])
    pressure_diff = abs(sensor["Pressure"] - api["Pressure"])

    attack = False

    if temp_diff > TEMP_THRESHOLD:
        attack = True

    if humidity_diff > HUMIDITY_THRESHOLD:
        attack = True

    if pressure_diff > PRESSURE_THRESHOLD:
        attack = True

    return {

        "Attack": attack,

        "TempDiff": round(temp_diff,2),

        "HumidityDiff": round(humidity_diff,2),

        "PressureDiff": round(pressure_diff,2)
    }