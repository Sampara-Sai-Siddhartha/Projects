"""
-------------------------------------------------------
Secure Human Workability Index System

Complete Live Detection Pipeline

Author : Sai Siddhartha
-------------------------------------------------------
"""

import time

from sheet_reader import (
    get_latest_sensor_data,
    read_sheet
)
from weather_api import get_weather_data
from hwi_calculator import calculate_hwi
from live_feature_engineering import LiveFeatureEngineering

from detection.rule_engine import RuleEngine
from detection.decision_fusion import DecisionFusion
from detection.temporal_detector import TemporalDetector

from models.predict_attack import predict_attack

from detection.fdi_detector import FDIDetector

# =====================================================
# Initialize Modules
# =====================================================

feature_engine = LiveFeatureEngineering()

rule_engine = RuleEngine()

fusion = DecisionFusion()

temporal_detector = TemporalDetector()

fdi_detector = FDIDetector()

# =====================================================
# Main Loop
# =====================================================

def main():

    print("=" * 70)
    print(" SECURE HUMAN WORKABILITY INDEX SYSTEM ")
    print("=" * 70)

    while True:

        # =====================================================
        # Read Latest Sensor Data
        # =====================================================

        print("\nReading Sensor Data...")

        sensor = get_latest_sensor_data()
        
        history_df = read_sheet()

        if sensor is None:

            print("Unable to read sensor data.")

            print("\nWaiting 10 Seconds...\n")

            time.sleep(10)

            continue

        # =====================================================
        # Temporal Security
        # =====================================================

        print("\nChecking Temporal Security...")

        temporal_result = temporal_detector.evaluate(sensor)

        print(temporal_result)

        # -----------------------------------------------------
        # No New Data
        # -----------------------------------------------------

        if temporal_result["Reasons"] == ["No New Data"]:

            print("\nNo New Sensor Data.")

            print("Waiting 10 Seconds...\n")

            time.sleep(10)

            continue

        # -----------------------------------------------------
        # Replay Attack
        # -----------------------------------------------------

        if temporal_result["ReplayAttack"]:

            print("\n⚠ REPLAY ATTACK DETECTED")

            print(
                "Reasons :",
                ", ".join(temporal_result["Reasons"])
            )

            print(
                "Replay Score :",
                temporal_result["ReplayScore"]
            )

            print(
                "Confidence :",
                temporal_result["Confidence"]
            )

            print("\nWaiting 10 Seconds...\n")

            time.sleep(10)

            continue

        # =====================================================
        # Display Sensor Data
        # =====================================================

        print("\nLatest Sensor Data")

        print(sensor)

        # =====================================================
        # Read Trusted Weather
        # =====================================================

        print("\nReading Trusted Weather...")

        weather = get_weather_data()

        print(weather)

        # =====================================================
        # Live Feature Engineering
        # =====================================================

        live_features = feature_engine.transform(sensor)

        # =====================================================
        # Machine Learning Detection
        # =====================================================

        # =====================================================
        # Isolation Forest
        # =====================================================

        ml_result = predict_attack(live_features)

        ml_prediction = ml_result.iloc[0]["Prediction"]

        print("\nIsolation Forest :", ml_prediction)

        isolation_anomaly = (
            ml_prediction == "Anomaly"
        )
        
        # =====================================================
        # False Data Injection Detector
        # =====================================================

        fdi_result = fdi_detector.evaluate(

        sensor_row=sensor,

        history_df=history_df,

        weather_data=weather,

        isolation_anomaly=isolation_anomaly

        )

        print("\n========== FDI DETECTOR ==========")

        print("FDI :", fdi_result["FDI"])

        print("Score :", fdi_result["FDIScore"])

        print("Confidence :", fdi_result["Confidence"])

        print("Reasons:")

        for reason in fdi_result["Reasons"]:

            print(" -", reason)

        # =====================================================
        # Rule Engine
        # =====================================================

        rule_result = rule_engine.evaluate(
            live_features.iloc[0]
        )

        print("Rule Engine :", rule_result)

        # =====================================================
        # Decision Fusion
        # =====================================================

        decision = fusion.fuse(

            rule_result=rule_result,

            ml_prediction=ml_prediction,

            fdi_result=fdi_result

        )

        print("\nDecision")

        print(decision)

        # =====================================================
        # Final Decision
        # =====================================================

        if decision["AttackDetected"]:

            print("\n⚠ CYBER ATTACK DETECTED")

            print("Type :", decision["AttackType"])

            print("Confidence :", decision["Confidence"])

        else:

            print("\nSensor Data Trusted")

            hwi = calculate_hwi(sensor)

            print("\nHuman Workability Index")

            for key, value in hwi.items():

                print(f"{key}: {value}")

        # =====================================================
        # Wait
        # =====================================================

        print("\nWaiting 10 Seconds...\n")

        time.sleep(10)


# =====================================================
# Start Application
# =====================================================

if __name__ == "__main__":

    main()