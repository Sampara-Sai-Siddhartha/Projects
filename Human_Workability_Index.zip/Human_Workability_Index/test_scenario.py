from attacks.scenario_generator import ScenarioGenerator

generator = ScenarioGenerator(dataset_size=20000)

events = generator.generate(n_events=10)

for event in events:
    print(event)