import os
import pandas as pd

LOG_FILE = "logs/sensor_log.csv"

def save_log(row):

    if os.path.exists(LOG_FILE):
        df = pd.read_csv(LOG_FILE)
        df.loc[len(df)] = row
    else:
        df = pd.DataFrame([row])

    df.to_csv(LOG_FILE, index=False)