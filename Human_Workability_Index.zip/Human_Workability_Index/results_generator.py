"""
-------------------------------------------------------
Results Generator
-------------------------------------------------------
Generates publication-quality figures for the
Secure Human Workability Index project.

Author : Sai Siddhartha
-------------------------------------------------------
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.metrics import (
    confusion_matrix,
    ConfusionMatrixDisplay,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score
)

# -------------------------------------------------------
# Paths
# -------------------------------------------------------

DATASET = "synthetic_dataset/engineered_dataset.csv"

OUTPUT_DIR = "results_figures"

os.makedirs(OUTPUT_DIR, exist_ok=True)

plt.rcParams["figure.figsize"] = (8, 6)
plt.rcParams["font.size"] = 12
plt.rcParams["axes.titlesize"] = 14
plt.rcParams["axes.labelsize"] = 12

print("=" * 60)
print("RESULTS FIGURE GENERATOR")
print("=" * 60)

df = pd.read_csv(DATASET)

print(f"Rows Loaded : {len(df)}")
# -------------------------------------------------------
# Figure 1 : Attack Distribution
# -------------------------------------------------------

attack_labels = {
    0: "Normal",
    1: "FDI",
    2: "Replay",
    3: "Noise",
    4: "Spike",
    5: "Frozen"
}

attack_counts = (
    df["Attack"]
    .value_counts()
    .sort_index()
)

labels = [
    attack_labels.get(i, str(i))
    for i in attack_counts.index
]

plt.figure(figsize=(8, 5))

bars = plt.bar(labels, attack_counts.values)

plt.title("Attack Distribution")
plt.xlabel("Attack Type")
plt.ylabel("Number of Samples")
plt.grid(axis="y", alpha=0.3)

for bar in bars:
    plt.text(
        bar.get_x() + bar.get_width()/2,
        bar.get_height() + 20,
        f"{int(bar.get_height())}",
        ha="center"
    )

plt.tight_layout()

plt.savefig(
    os.path.join(
        OUTPUT_DIR,
        "Figure_1_Attack_Distribution.png"
    ),
    dpi=300
)

plt.close()

print("Figure 1 Generated")
# -------------------------------------------------------
# Figure 2 : Isolation Forest Performance
# -------------------------------------------------------

accuracy = 0.8907
precision = 0.1555
recall = 0.1039
f1 = 0.1246
roc_auc = 0.5291

metrics = [
    "Accuracy",
    "Precision",
    "Recall",
    "F1 Score",
    "ROC AUC"
]

values = [
    accuracy,
    precision,
    recall,
    f1,
    roc_auc
]

plt.figure(figsize=(9,6))

bars = plt.bar(
    metrics,
    values,
    edgecolor="black",
    linewidth=1.2
)

plt.ylim(0,1.0)

plt.title(
    "Isolation Forest Performance Metrics",
    fontsize=16,
    fontweight="bold"
)

plt.ylabel("Score")
plt.grid(axis="y", alpha=0.3)

for bar, value in zip(bars, values):

    plt.text(
        bar.get_x()+bar.get_width()/2,
        value+0.02,
        f"{value:.3f}",
        ha="center",
        fontsize=11,
        fontweight="bold"
    )

plt.tight_layout()

plt.savefig(
    os.path.join(
        OUTPUT_DIR,
        "Figure_2_IsolationForest_Performance.png"
    ),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Figure 2 Generated")
# -------------------------------------------------------
# Figure 3 : Model Performance Comparison
# -------------------------------------------------------

models = [
    "Isolation\nForest",
    "Rule\nEngine",
    "FDI\nDetector",
    "Hybrid\nFusion"
]

accuracy = [0.8907, 0.4913, 0.9252, 0.4913]
precision = [0.1555, 0.0815, 0.1855, 0.0815]
recall = [0.1039, 0.5649, 0.1239, 0.5649]
f1_score = [0.1246, 0.1425, 0.1446, 0.1425]
roc_auc = [0.5291, 0.5251, 0.5000, 0.5251]

x = np.arange(len(models))
width = 0.16

plt.figure(figsize=(12,7))

plt.bar(x - 2*width, accuracy, width,
        label="Accuracy",
        edgecolor="black")

plt.bar(x - width, precision, width,
        label="Precision",
        edgecolor="black")

plt.bar(x, recall, width,
        label="Recall",
        edgecolor="black")

plt.bar(x + width, f1_score, width,
        label="F1 Score",
        edgecolor="black")

plt.bar(x + 2*width, roc_auc, width,
        label="ROC AUC",
        edgecolor="black")

plt.xticks(x, models)

plt.ylabel("Score")

plt.ylim(0,1.05)

plt.title(
    "Performance Comparison of Cyberattack Detection Models",
    fontsize=16,
    fontweight="bold"
)

plt.grid(axis="y", alpha=0.3)

plt.legend(loc="upper right")

plt.tight_layout()

plt.savefig(
    os.path.join(
        OUTPUT_DIR,
        "Figure_3_Model_Comparison.png"
    ),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Figure 3 Generated")
# -------------------------------------------------------
# Figure 4 : Isolation Forest Confusion Matrix
# -------------------------------------------------------

cm = np.array([
    [16918, 809],
    [1285, 149]
])

classes = ["Normal", "Attack"]

fig, ax = plt.subplots(figsize=(7, 6))

im = ax.imshow(cm, cmap="Blues")

cbar = plt.colorbar(im)
cbar.set_label("Number of Samples", fontsize=11)

ax.set_xticks(np.arange(len(classes)))
ax.set_yticks(np.arange(len(classes)))

ax.set_xticklabels(classes, fontsize=12)
ax.set_yticklabels(classes, fontsize=12)

ax.set_xlabel(
    "Predicted Class",
    fontsize=13,
    fontweight="bold"
)

ax.set_ylabel(
    "Actual Class",
    fontsize=13,
    fontweight="bold"
)

ax.set_title(
    "Isolation Forest Confusion Matrix",
    fontsize=16,
    fontweight="bold"
)

threshold = cm.max() / 2

for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):

        ax.text(
            j,
            i,
            f"{cm[i, j]:,}",
            ha="center",
            va="center",
            fontsize=14,
            fontweight="bold",
            color="white" if cm[i, j] > threshold else "black"
        )

plt.tight_layout()

plt.savefig(
    os.path.join(
        OUTPUT_DIR,
        "Figure_4_IsolationForest_ConfusionMatrix.png"
    ),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Figure 4 Generated")
# -------------------------------------------------------
# Figure 5 : Hybrid Decision Fusion Confusion Matrix
# -------------------------------------------------------

cm = np.array([
    [8604, 9123],
    [624, 810]
])

classes = ["Normal", "Attack"]

fig, ax = plt.subplots(figsize=(7, 6))

im = ax.imshow(cm, cmap="Greens")

cbar = plt.colorbar(im)
cbar.set_label("Number of Samples", fontsize=11)

ax.set_xticks(np.arange(len(classes)))
ax.set_yticks(np.arange(len(classes)))

ax.set_xticklabels(classes, fontsize=12)
ax.set_yticklabels(classes, fontsize=12)

ax.set_xlabel(
    "Predicted Class",
    fontsize=13,
    fontweight="bold"
)

ax.set_ylabel(
    "Actual Class",
    fontsize=13,
    fontweight="bold"
)

ax.set_title(
    "Hybrid Decision Fusion Confusion Matrix",
    fontsize=16,
    fontweight="bold"
)

threshold = cm.max() / 2

for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):

        ax.text(
            j,
            i,
            f"{cm[i, j]:,}",
            ha="center",
            va="center",
            fontsize=14,
            fontweight="bold",
            color="white" if cm[i, j] > threshold else "black"
        )

# Display percentages inside each cell
total = cm.sum()

for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):

        percentage = (cm[i, j] / total) * 100

        ax.text(
            j,
            i + 0.18,
            f"({percentage:.1f}%)",
            ha="center",
            va="center",
            fontsize=10,
            color="yellow" if cm[i, j] > threshold else "black"
        )

plt.tight_layout()

plt.savefig(
    os.path.join(
        OUTPUT_DIR,
        "Figure_5_Hybrid_ConfusionMatrix.png"
    ),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Figure 5 Generated")
# -------------------------------------------------------
# Figure 6 : ROC Curve
# -------------------------------------------------------

from sklearn.metrics import roc_curve, auc

pred_df = pd.read_csv("results/hybrid_predictions_v2.csv")

# Actual labels
y_true = pred_df["GroundTruth"]

# Isolation Forest predictions
y_pred = pred_df["IsolationForest"]

# ROC
fpr, tpr, _ = roc_curve(y_true, y_pred)

roc_auc = auc(fpr, tpr)

plt.figure(figsize=(8,6))

plt.plot(
    fpr,
    tpr,
    linewidth=3,
    label=f"Isolation Forest (AUC = {roc_auc:.3f})"
)

plt.plot(
    [0,1],
    [0,1],
    linestyle="--",
    linewidth=2,
    label="Random Classifier"
)

plt.xlabel(
    "False Positive Rate",
    fontsize=13,
    fontweight="bold"
)

plt.ylabel(
    "True Positive Rate",
    fontsize=13,
    fontweight="bold"
)

plt.title(
    "Receiver Operating Characteristic (ROC) Curve",
    fontsize=16,
    fontweight="bold"
)

plt.grid(alpha=0.3)

plt.legend(fontsize=11)

plt.tight_layout()

plt.savefig(
    os.path.join(
        OUTPUT_DIR,
        "Figure_6_ROC_Curve.png"
    ),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Figure 6 Generated")
# -------------------------------------------------------
# Figure 7 : Precision-Recall Curve
# -------------------------------------------------------

from sklearn.metrics import (
    precision_recall_curve,
    average_precision_score
)

pred_df = pd.read_csv("results/hybrid_predictions_v2.csv")

y_true = pred_df["GroundTruth"]

y_pred = pred_df["IsolationForest"]

# Precision-Recall Curve
precision, recall, _ = precision_recall_curve(
    y_true,
    y_pred
)

ap = average_precision_score(
    y_true,
    y_pred
)

plt.figure(figsize=(8,6))

plt.plot(
    recall,
    precision,
    linewidth=3,
    label=f"Average Precision = {ap:.3f}"
)

plt.xlabel(
    "Recall",
    fontsize=13,
    fontweight="bold"
)

plt.ylabel(
    "Precision",
    fontsize=13,
    fontweight="bold"
)

plt.title(
    "Precision-Recall Curve",
    fontsize=16,
    fontweight="bold"
)

plt.grid(alpha=0.3)

plt.legend(
    loc="lower left",
    fontsize=11
)

plt.tight_layout()

plt.savefig(
    os.path.join(
        OUTPUT_DIR,
        "Figure_7_Precision_Recall_Curve.png"
    ),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Figure 7 Generated")
# -------------------------------------------------------
# Figure 8 : Rule Engine Detection Summary
# -------------------------------------------------------

categories = [
    "Correct\nDetections",
    "False\nAlarms",
    "Frozen\nSensor\nTriggers"
]

values = [
    808,
    9122,
    9930
]

plt.figure(figsize=(8,6))

bars = plt.bar(
    categories,
    values,
    edgecolor="black"
)

# Display values on bars
for bar in bars:
    height = bar.get_height()
    plt.text(
        bar.get_x() + bar.get_width()/2,
        height + max(values)*0.01,
        f"{int(height):,}",
        ha="center",
        fontsize=11,
        fontweight="bold"
    )

plt.ylabel(
    "Number of Events",
    fontsize=13,
    fontweight="bold"
)

plt.title(
    "Rule Engine Detection Summary",
    fontsize=16,
    fontweight="bold"
)

plt.grid(axis="y", alpha=0.3)

plt.tight_layout()

plt.savefig(
    os.path.join(
        OUTPUT_DIR,
        "Figure_8_Rule_Engine_Summary.png"
    ),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Figure 8 Generated")
# -------------------------------------------------------
# Figure 9 : Detection Outcome Analysis
# -------------------------------------------------------

categories = [
    "True\nNegative",
    "False\nPositive",
    "False\nNegative",
    "True\nPositive"
]

values = [
    16918,
    809,
    1285,
    149
]

plt.figure(figsize=(9,6))

bars = plt.bar(
    categories,
    values,
    edgecolor="black"
)

# Display values above bars
for bar in bars:
    height = bar.get_height()
    plt.text(
        bar.get_x() + bar.get_width()/2,
        height + max(values)*0.01,
        f"{height:,}",
        ha="center",
        fontsize=11,
        fontweight="bold"
    )

plt.ylabel(
    "Number of Samples",
    fontsize=13,
    fontweight="bold"
)

plt.title(
    "Isolation Forest Detection Outcome Analysis",
    fontsize=16,
    fontweight="bold"
)

plt.grid(axis="y", alpha=0.3)

plt.tight_layout()

plt.savefig(
    os.path.join(
        OUTPUT_DIR,
        "Figure_9_Detection_Outcome_Analysis.png"
    ),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Figure 9 Generated")
# -------------------------------------------------------
# Figure 10 : Sensor Timeline with Attack Regions
# -------------------------------------------------------

# Use the first 1000 samples for better visualization
plot_df = df.iloc[:1000].copy()

plt.figure(figsize=(14,6))

# Plot Temperature
plt.plot(
    plot_df.index,
    plot_df["Temperature(°C)"],
    linewidth=1.5,
    label="Temperature (°C)"
)

# Highlight attack regions
attack_mask = plot_df["Attack"] != 0

plt.scatter(
    plot_df.index[attack_mask],
    plot_df.loc[attack_mask, "Temperature(°C)"],
    marker="o",
    s=18,
    label="Attack Samples"
)

plt.xlabel(
    "Sample Index",
    fontsize=13,
    fontweight="bold"
)

plt.ylabel(
    "Temperature (°C)",
    fontsize=13,
    fontweight="bold"
)

plt.title(
    "Temperature Sensor Timeline with Attack Regions",
    fontsize=16,
    fontweight="bold"
)

plt.grid(alpha=0.3)

plt.legend()

plt.tight_layout()

plt.savefig(
    os.path.join(
        OUTPUT_DIR,
        "Figure_10_Temperature_Attack_Timeline.png"
    ),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Figure 10 Generated")
# -------------------------------------------------------
# Figure 11 : Multi-Sensor Timeline with Attack Regions
# -------------------------------------------------------

# Use first 1000 samples for visualization
plot_df = df.iloc[:1000].copy()

fig, axes = plt.subplots(3, 1, figsize=(14, 10), sharex=True)

sensor_info = [
    ("Temperature(°C)", "Temperature"),
    ("Humidity(%)", "Humidity"),
    ("Pressure(hPa)", "Pressure")
]

attack_mask = plot_df["Attack"] != 0

for ax, (column, title) in zip(axes, sensor_info):

    # Plot sensor signal
    ax.plot(
        plot_df.index,
        plot_df[column],
        linewidth=1.5,
        label=title
    )

    # Highlight attack samples
    ax.scatter(
        plot_df.index[attack_mask],
        plot_df.loc[attack_mask, column],
        s=18,
        marker="o",
        label="Attack Samples"
    )

    ax.set_ylabel(title, fontsize=11, fontweight="bold")
    ax.grid(alpha=0.3)
    ax.legend(loc="upper right")

axes[-1].set_xlabel(
    "Sample Index",
    fontsize=12,
    fontweight="bold"
)

fig.suptitle(
    "Multi-Sensor Timeline with Attack Regions",
    fontsize=16,
    fontweight="bold"
)

plt.tight_layout(rect=[0, 0, 1, 0.96])

plt.savefig(
    os.path.join(
        OUTPUT_DIR,
        "Figure_11_MultiSensor_Timeline.png"
    ),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Figure 11 Generated")
# -------------------------------------------------------
# Figure 12 : Proposed Secure HWI Framework
# -------------------------------------------------------

from matplotlib.patches import FancyBboxPatch

fig, ax = plt.subplots(figsize=(18, 7))

ax.set_xlim(0, 22)
ax.set_ylim(0, 8)
ax.axis("off")

def draw_box(x, y, w, h, text):
    box = FancyBboxPatch(
        (x, y),
        w,
        h,
        boxstyle="round,pad=0.3",
        linewidth=2,
        edgecolor="black",
        facecolor="white"
    )
    ax.add_patch(box)

    ax.text(
        x + w/2,
        y + h/2,
        text,
        ha="center",
        va="center",
        fontsize=10,
        fontweight="bold",
        wrap=True
    )

def arrow(x1, y1, x2, y2):
    ax.annotate(
        "",
        xy=(x2, y2),
        xytext=(x1, y1),
        arrowprops=dict(
            arrowstyle="->",
            lw=2
        )
    )

# Main pipeline
draw_box(0.5, 3.3, 2.3, 1.2,
         "IoT Sensors\nTemperature\nHumidity\nPressure")

draw_box(3.5, 3.3, 2.3, 1.2,
         "Data\nAcquisition")

draw_box(6.5, 3.3, 2.5, 1.2,
         "Preprocessing\nCleaning\nNormalization")

draw_box(10, 3.3, 2.5, 1.2,
         "Feature\nEngineering")

draw_box(13.5, 5.5, 2.6, 1.2,
         "Isolation\nForest")

draw_box(13.5, 3.3, 2.6, 1.2,
         "Rule\nEngine")

draw_box(13.5, 1.1, 2.6, 1.2,
         "FDI\nDetector")

draw_box(17.2, 3.3, 2.8, 1.2,
         "Decision\nFusion")

draw_box(20.5, 3.3, 1.3, 1.2,
         "HWI\nScore")

draw_box(20.5, 6.0, 1.3, 1.0,
         "Dashboard")

# Main arrows
arrow(2.8, 3.9, 3.5, 3.9)
arrow(5.8, 3.9, 6.5, 3.9)
arrow(9.0, 3.9, 10.0, 3.9)

# Split arrows
arrow(12.5, 4.2, 13.5, 6.1)
arrow(12.5, 3.9, 13.5, 3.9)
arrow(12.5, 3.6, 13.5, 1.7)

# Merge arrows
arrow(16.1, 6.1, 17.2, 4.2)
arrow(16.1, 3.9, 17.2, 3.9)
arrow(16.1, 1.7, 17.2, 3.6)

arrow(20.0, 3.9, 20.5, 3.9)
arrow(21.15, 4.5, 21.15, 6.0)

plt.title(
    "Proposed Secure Human Workability Index Framework",
    fontsize=18,
    fontweight="bold"
)

plt.tight_layout()

plt.savefig(
    os.path.join(
        OUTPUT_DIR,
        "Figure_12_Proposed_Framework.png"
    ),
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Figure 12 Generated")