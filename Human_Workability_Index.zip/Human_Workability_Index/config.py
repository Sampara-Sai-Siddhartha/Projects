from dotenv import load_dotenv
import os

load_dotenv()
# ================================
# Google Sheet Configuration
# ================================

SHEET_ID = "1B0NMUnUoYyQ8SzzmKOWPkyhBKA9A-mBg-jRoN6i_qa4"

# -----------------------------
# OpenWeather
# -----------------------------

OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY")

LATITUDE = 16.46323
LONGITUDE = 80.50641

# -----------------------------
# FDI Thresholds
# -----------------------------

TEMP_THRESHOLD = 2.0          # °C
HUMIDITY_THRESHOLD = 10.0     # %
PRESSURE_THRESHOLD = 5.0      # hPa

# ================================
# Human Workability Index Weights
# ================================

TEMPERATURE_WEIGHT = 0.30
HUMIDITY_WEIGHT = 0.15
HEAT_INDEX_WEIGHT = 0.25
AQI_WEIGHT = 0.15
GAS_WEIGHT = 0.10
DEWPOINT_WEIGHT = 0.05