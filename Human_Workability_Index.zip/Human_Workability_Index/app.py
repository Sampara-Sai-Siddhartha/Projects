from flask import Flask, render_template, jsonify

from sheet_reader import (
    get_latest_sensor_data,
    read_sheet
)

from weather_api import get_weather_data
from hwi_calculator import calculate_hwi
from live_feature_engineering import LiveFeatureEngineering

from detection.rule_engine import RuleEngine
from detection.decision_fusion import DecisionFusion
from detection.fdi_detector import FDIDetector
from detection.temporal_detector import TemporalDetector
from models.predict_attack import predict_attack
from datetime import datetime

app = Flask(__name__)

feature_engine = LiveFeatureEngineering()
rule_engine = RuleEngine()
fusion = DecisionFusion()
fdi_detector = FDIDetector()
temporal_detector = TemporalDetector()

def generate_recommendation(hwi):

    if hwi is None:
        return "⚠ SECURITY WARNING - Dashboard Frozen"

    score = hwi["HWI"]

    if score >= 85:
        return "Excellent working conditions. Continue normal operation."

    elif score >= 70:
        return "Good working conditions. Maintain regular monitoring."

    elif score >= 50:
        return "Moderate conditions. Increase hydration and rest."

    else:
        return "Unsafe environment. Reduce workload immediately."

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/api/data")
def api_data():

    # -------------------------------------------------
    # Read Sensor Data
    # -------------------------------------------------

    sensor = get_latest_sensor_data()
    history_df = read_sheet()

    # -------------------------------------------------
    # Replay Attack Detection
    # -------------------------------------------------

    temporal_result = temporal_detector.evaluate(sensor)

    # Duplicate polling (same row fetched again)
    if temporal_result["Reasons"] == ["No New Data"]:

        timestamp = datetime.now().strftime("%H:%M:%S")

        return jsonify({

            "timestamp": timestamp,

            "sensor": sensor.to_dict(),

            "weather": {},

            "hwi": None,

            "recommendation": "Waiting for new sensor data.",

            "attack": {

                "AttackDetected": False,

                "AttackTypes": ["No New Data"],

                "Confidence": 0

            }

        })

    # Replay Attack Detected
    if temporal_result["ReplayAttack"]:

        timestamp = datetime.now().strftime("%H:%M:%S")

        return jsonify({

            "timestamp": timestamp,

            "sensor": sensor.to_dict(),

            "weather": {},

            "hwi": None,

            "recommendation": "⚠ Replay Attack Detected. Dashboard Frozen.",

            "attack": {

                "AttackDetected": True,

                "AttackTypes": ["Replay Attack"],

                "Confidence": temporal_result["ReplayScore"]

            }

        })

    # -------------------------------------------------
    # Weather
    # -------------------------------------------------

    weather = get_weather_data()

    # -------------------------------------------------
    # Feature Engineering
    # -------------------------------------------------

    live_features = feature_engine.transform(sensor)

    # -------------------------------------------------
    # Isolation Forest
    # -------------------------------------------------

    ml_result = predict_attack(live_features)

    ml_prediction = ml_result.iloc[0]["Prediction"]

    isolation_anomaly = (
        ml_prediction == "Anomaly"
    )

    # -------------------------------------------------
    # False Data Injection Detector
    # -------------------------------------------------

    fdi_result = fdi_detector.evaluate(

        sensor_row=sensor,

        history_df=history_df,

        weather_data=weather,

        isolation_anomaly=isolation_anomaly

    )

    # -------------------------------------------------
    # Rule Engine
    # -------------------------------------------------

    rule_result = rule_engine.evaluate(
        live_features.iloc[0]
    )
    print("TYPE =", type(rule_result))
    print("VALUE =", rule_result)

    # -------------------------------------------------
    # Decision Fusion
    # -------------------------------------------------

    decision = fusion.fuse(

        rule_result=rule_result,

        ml_prediction=ml_prediction,

        fdi_result=fdi_result

    )
    # -------------------------------------------------
    # Build Attack List
    # -------------------------------------------------

    attack_list = []

    # Replay Attack
    if temporal_result["ReplayAttack"]:
        attack_list.append("Replay Attack")

    # Rule Engine Attacks (rule_result is already a list)
    if len(rule_result) > 0:
        attack_list.extend(rule_result)

    # False Data Injection
    if fdi_result["FDI"]:
        attack_list.append("False Data Injection")

    # Isolation Forest
    if isolation_anomaly:
        attack_list.append("Isolation Forest Anomaly")
        
    # Remove duplicates
    attack_list = list(dict.fromkeys(attack_list))

    # No Attack
    if len(attack_list) == 0:
        attack_list.append("No Active Attack")

    # -------------------------------------------------
    # HWI
    # -------------------------------------------------

    if decision["AttackDetected"]:

        hwi = None

        recommendation = "Dashboard Frozen"

    else:

        hwi = calculate_hwi(sensor)

        recommendation = generate_recommendation(hwi)
        
    timestamp = datetime.now().strftime("%H:%M:%S")

    # -------------------------------------------------
    # Dashboard JSON
    # -------------------------------------------------

    return jsonify({

        "timestamp": timestamp,

        "sensor": sensor.to_dict(),

        "weather": weather,

        "hwi": hwi,

        "recommendation": recommendation,

        "attack": {

            "AttackDetected": decision["AttackDetected"],

            "AttackTypes": attack_list,

            "Confidence": decision["Confidence"]

        }

    })


if __name__ == "__main__":
    app.run(debug=True)