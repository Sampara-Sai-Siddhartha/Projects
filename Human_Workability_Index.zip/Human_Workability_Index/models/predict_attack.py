"""
-------------------------------------------------------
Real-Time Attack Prediction

Loads the trained Isolation Forest model
and predicts whether incoming sensor data
is Normal or Anomalous.

Author : Sai Siddhartha
-------------------------------------------------------
"""

import joblib
import pandas as pd


# ======================================================
# Load Model
# ======================================================

MODEL_PATH = "models/isolation_forest.pkl"

model = joblib.load(MODEL_PATH)

print("Isolation Forest Loaded Successfully")


# ======================================================
# Prediction Function
# ======================================================

FEATURES = [

    "Temperature(°C)",
    "Humidity(%)",
    "Pressure(hPa)",

    "TempRate",
    "HumidityRate",
    "PressureRate",

    "RollingMeanTemp",
    "RollingStdTemp",

    "ConstantTempCount",

    "ConstantHumidityCount",

    "ConstantPressureCount",

    "MissingFlag",

    "DuplicateFlag"
]


def predict_attack(sensor_df):

    X = sensor_df[FEATURES]

    prediction = model.predict(X)

    sensor_df["Prediction"] = prediction

    sensor_df["Prediction"] = sensor_df["Prediction"].replace({

        1: "Normal",

        -1: "Attack"

    })

    return sensor_df