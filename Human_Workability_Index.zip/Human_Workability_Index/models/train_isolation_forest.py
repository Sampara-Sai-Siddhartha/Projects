"""
-------------------------------------------------------
Isolation Forest Training
-------------------------------------------------------

Author : Sai Siddhartha
Project : Secure Human Workability Index
-------------------------------------------------------
"""

import joblib
import pandas as pd

from sklearn.ensemble import IsolationForest


# ======================================================
# Load Dataset
# ======================================================

DATASET = "synthetic_dataset/engineered_dataset.csv"

MODEL_FILE = "models/isolation_forest.pkl"


print("=" * 60)
print("Isolation Forest Training")
print("=" * 60)

df = pd.read_csv(DATASET)

print(f"Rows : {len(df)}")


# ======================================================
# Features
# ======================================================

FEATURES = [

    "Temperature(°C)",
    "Humidity(%)",
    "Pressure(hPa)",

    "TempRate",
    "HumidityRate",
    "PressureRate",

    "RollingMeanTemp",
    "RollingStdTemp",

    "ConstantTempCount",

    "ConstantHumidityCount",

    "ConstantPressureCount",

    "MissingFlag",

    "DuplicateFlag"
]


X = df[FEATURES]


# ======================================================
# Train Model
# ======================================================

model = IsolationForest(

    n_estimators=200,

    contamination=0.075,

    random_state=42

)

model.fit(X)

print("\nTraining Completed")


# ======================================================
# Save Model
# ======================================================

joblib.dump(model, MODEL_FILE)

print("\nModel Saved")

print(MODEL_FILE)

print("=" * 60)