from config import *

# ------------------------------------
# Utility Function
# ------------------------------------

def normalize(value, minimum, maximum):
    """
    Converts a value into 0-100 range.
    """

    value = max(minimum, min(value, maximum))

    return ((value - minimum) / (maximum - minimum)) * 100


# ------------------------------------
# Heat Stress Risk
# ------------------------------------

def heat_stress(temp, humidity, heat_index):

    temp_score = normalize(temp, 20, 45)
    humidity_score = normalize(humidity, 20, 100)
    heat_index_score = normalize(heat_index, 20, 55)

    risk = (
        temp_score * 0.4 +
        humidity_score * 0.2 +
        heat_index_score * 0.4
    )

    return round(risk, 2)


# ------------------------------------
# Physical Capacity
# ------------------------------------

def physical_capacity(temp, heat_index, aqi):

    temp_score = normalize(temp, 20, 45)
    heat_score = normalize(heat_index, 20, 55)
    aqi_score = normalize(aqi, 0, 300)

    capacity = 100 - (
        temp_score * 0.4 +
        heat_score * 0.4 +
        aqi_score * 0.2
    )

    return round(max(0, capacity), 2)


# ------------------------------------
# Mental Focus
# ------------------------------------

def mental_focus(aqi, gas):

    aqi_score = normalize(aqi, 0, 300)

    # Higher gas resistance generally indicates cleaner air.
    gas_score = 100 - normalize(gas, 100, 600)

    focus = 100 - (
        aqi_score * 0.7 +
        gas_score * 0.3
    )

    return round(max(0, focus), 2)


# ------------------------------------
# Fatigue Risk
# ------------------------------------

def fatigue_risk(temp, humidity, gas):

    temp_score = normalize(temp, 20, 45)
    humidity_score = normalize(humidity, 20, 100)
    gas_score = 100 - normalize(gas, 100, 600)

    fatigue = (
        temp_score * 0.4 +
        humidity_score * 0.3 +
        gas_score * 0.3
    )

    return round(fatigue, 2)


# ------------------------------------
# Overall HWI
# ------------------------------------

def calculate_hwi(sensor):

    temp = sensor["Temperature(°C)"]
    humidity = sensor["Humidity(%)"]
    heat_index = sensor["HeatIndex(°C)"]
    aqi = sensor["AQI"]
    gas = sensor["Gas (kOhms)"]
    dewpoint = sensor["DewPoint(°C)"]

    heat = heat_stress(
        temp,
        humidity,
        heat_index
    )

    physical = physical_capacity(
        temp,
        heat_index,
        aqi
    )

    mental = mental_focus(
        aqi,
        gas
    )

    fatigue = fatigue_risk(
        temp,
        humidity,
        gas
    )

    hwi = (
        physical +
        mental +
        (100 - heat) +
        (100 - fatigue)
    ) / 4

    hwi = round(hwi, 2)

    return {
        "Physical Capacity": physical,
        "Mental Focus": mental,
        "Heat Stress": heat,
        "Fatigue Risk": fatigue,
        "HWI": hwi
    }


# ------------------------------------
# Recommendation
# ------------------------------------

def recommendation(hwi):

    if hwi >= 90:
        return "Continue working normally."

    elif hwi >= 75:
        return "Drink 250 mL of water and continue."

    elif hwi >= 60:
        return "Take a short break and hydrate."

    elif hwi >= 40:
        return "Take a 20-minute break, drink 500 mL water, and move to shade."

    else:
        return "STOP WORK. High heat risk. Move indoors and hydrate immediately."