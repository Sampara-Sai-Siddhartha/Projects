from flask import Flask, request, render_template
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np
import os

app = Flask(__name__)

# Load the trained model
model = load_model('accident_severity_model.h5')

# Ensure upload folder exists
UPLOAD_FOLDER = './static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    file = request.files['file']
    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)

    # Preprocess the image
    img = image.load_img(file_path, target_size=(224, 224))
    img_array = image.img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    # Make predictions
    predictions = model.predict(img_array)
    severity_class = np.argmax(predictions)
    severity_labels = {0: 'Minor', 1: 'Moderate', 2: 'Severe'}
    result = severity_labels[severity_class]
    confidence = float(predictions[0][severity_class] * 100)  # Convert to Python float

    # Generate advice based on severity
    if result == 'Minor':
        advice = "Passengers are safe with minor damage."
    elif result == 'Moderate':
        advice = "Passengers may have small injuries."
    else:
        advice = "Passengers may face big injuries."

    # Additional metrics (converted to Python floats)
    metrics = {
        "Minor": float(predictions[0][0] * 100),
        "Moderate": float(predictions[0][1] * 100),
        "Severe": float(predictions[0][2] * 100),
        "Confidence": confidence
    }

    return render_template(
        'index.html',
        prediction=result,
        advice=advice,
        image_path=file_path,
        metrics=metrics
    )


if __name__ == '__main__':
    app.run(debug=True)
